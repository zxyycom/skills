"""Measure one isolated CLI process; fixture setup and posterior are external."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time


ROOT = Path(__file__).resolve().parents[1]


@dataclass(frozen=True)
class Measurement:
    argv: tuple[str, ...]
    cwd: Path
    output_prefix: Path
    timeout_seconds: float
    domain: str
    scenario: str
    iteration: int
    mode: str
    environment: dict[str, str]


def owned_path(value: object, label: str) -> Path:
    if not isinstance(value, str):
        raise ValueError(f"{label} must be an absolute owned path")
    path = Path(value)
    if not path.is_absolute() or not path.resolve().is_relative_to(ROOT):
        raise ValueError(f"{label} escapes the benchmark root")
    return path


def required_text(value: object, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError(f"{label} must be nonempty text")
    return value


def parse_measurement(value: object) -> Measurement:
    if not isinstance(value, dict):
        raise ValueError("measurement specification must be an object")
    argv = value.get("argv")
    if not isinstance(argv, list) or not argv or any(
        not isinstance(item, str) for item in argv
    ):
        raise ValueError("argv must be a nonempty string array")
    timeout = value.get("timeoutSeconds", 600)
    if isinstance(timeout, bool) or not isinstance(timeout, (int, float)):
        raise ValueError("timeoutSeconds must be numeric")
    if not 0 < timeout <= 600:
        raise ValueError("timeoutSeconds must be within (0, 600]")
    iteration = value.get("iteration")
    if isinstance(iteration, bool) or not isinstance(iteration, int) or iteration < 0:
        raise ValueError("iteration must be a nonnegative integer")
    mode = value.get("mode")
    if mode not in {"normal", "instrumented", "smoke", "collector-selfcheck"}:
        raise ValueError("invalid measurement mode")
    environment = value.get("environment", {})
    if not isinstance(environment, dict) or any(
        not isinstance(key, str)
        or not key.startswith("RECORD_BENCH_")
        or not isinstance(item, str)
        for key, item in environment.items()
    ):
        raise ValueError("environment permits only RECORD_BENCH_* string values")
    cwd = owned_path(value.get("cwd"), "cwd")
    if not cwd.is_dir():
        raise ValueError("cwd does not exist")
    return Measurement(
        tuple(argv), cwd, owned_path(value.get("outputPrefix"), "outputPrefix"),
        float(timeout), required_text(value.get("domain"), "domain"),
        required_text(value.get("scenario"), "scenario"), iteration, mode,
        dict(environment),
    )


def subprocess_environment(extra: dict[str, str]) -> dict[str, str]:
    environment = dict(os.environ)
    for key in list(environment):
        if key.startswith("GIT_") or key.startswith("RECORD_BENCH_"):
            del environment[key]
    for key in ("NODE_PATH", "NODE_V8_COVERAGE", "NODE_COMPILE_CACHE"):
        environment.pop(key, None)
    environment.update({
        "NODE_OPTIONS": "", "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_CONFIG_GLOBAL": os.devnull, "TZ": "UTC", "LC_ALL": "C.UTF-8",
    })
    environment.update(extra)
    return environment


def terminate_at_deadline(
    pid: int, timeout: float, finished: threading.Event, timed_out: threading.Event
) -> None:
    if finished.wait(timeout):
        return
    timed_out.set()
    try:
        os.killpg(pid, signal.SIGKILL)
    except ProcessLookupError:
        pass


def output_identity(path: Path) -> dict[str, object]:
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


def wait_for_process(
    specification: Measurement, stdout: object, stderr: object
) -> dict[str, object]:
    finished = threading.Event()
    timed_out = threading.Event()
    started = time.perf_counter()
    try:
        process = subprocess.Popen(
            specification.argv, cwd=specification.cwd, stdout=stdout, stderr=stderr,
            env=subprocess_environment(specification.environment), start_new_session=True,
        )
    except OSError as error:
        return {
            "outcome": "spawn-error", "spawnError": {"errno": error.errno, "message": str(error)},
            "wallSeconds": time.perf_counter() - started, "timedOut": False,
            "exitCode": None, "userSeconds": None, "systemSeconds": None,
            "cpuSeconds": None, "maxRssKiB": None,
        }
    deadline = threading.Thread(
        target=terminate_at_deadline,
        args=(process.pid, specification.timeout_seconds, finished, timed_out),
        daemon=True,
    )
    deadline.start()
    try:
        _, status, usage = os.wait4(process.pid, 0)
        elapsed = time.perf_counter() - started
        process.returncode = os.waitstatus_to_exitcode(status)
    except BaseException:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        _, status, _ = os.wait4(process.pid, 0)
        process.returncode = os.waitstatus_to_exitcode(status)
        raise
    finally:
        finished.set()
        deadline.join()
    return {
        "outcome": "timeout" if timed_out.is_set() else "exited",
        "timedOut": timed_out.is_set(), "exitCode": process.returncode,
        "wallSeconds": elapsed, "userSeconds": usage.ru_utime,
        "systemSeconds": usage.ru_stime,
        "cpuSeconds": usage.ru_utime + usage.ru_stime,
        "maxRssKiB": usage.ru_maxrss, "minorFaults": usage.ru_minflt,
        "majorFaults": usage.ru_majflt, "voluntaryContextSwitches": usage.ru_nvcsw,
        "involuntaryContextSwitches": usage.ru_nivcsw,
    }


def run_measurement(specification: Measurement) -> dict[str, object]:
    prefix = specification.output_prefix
    prefix.parent.mkdir(parents=True, exist_ok=True)
    stdout_path = Path(str(prefix) + ".stdout")
    stderr_path = Path(str(prefix) + ".stderr")
    metrics_path = Path(str(prefix) + ".metrics.json")
    for path in (stdout_path, stderr_path, metrics_path):
        if path.exists():
            raise FileExistsError(f"refusing to replace a prior observation: {path}")
    with stdout_path.open("xb") as stdout, stderr_path.open("xb") as stderr:
        started_at = datetime.now(timezone.utc).isoformat()
        process_result = wait_for_process(specification, stdout, stderr)
    result = {
        "schemaVersion": 1, "domain": specification.domain,
        "scenario": specification.scenario, "iteration": specification.iteration,
        "mode": specification.mode, "argv": list(specification.argv),
        "cwd": str(specification.cwd), "startedAt": started_at,
        "finishedAt": datetime.now(timezone.utc).isoformat(),
        "timeoutSeconds": specification.timeout_seconds,
        **process_result,
        "stdout": output_identity(stdout_path), "stderr": output_identity(stderr_path),
    }
    with metrics_path.open("x") as output:
        json.dump(result, output, ensure_ascii=False, indent=2)
        output.write("\n")
    return result


def main() -> None:
    if sys.platform != "linux":
        raise RuntimeError("this collector's RSS units are defined only on Linux")
    if len(sys.argv) != 2:
        raise ValueError("usage: measure.py <specification.json>")
    specification_path = owned_path(sys.argv[1], "specification")
    result = run_measurement(parse_measurement(json.loads(specification_path.read_text())))
    print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
