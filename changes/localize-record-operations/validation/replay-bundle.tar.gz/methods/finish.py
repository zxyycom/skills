"""Close source/dependency/runtime provenance after all measurement/control processes."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,subprocess,os
from freeze import fingerprint,REPO
ROOT=Path(__file__).resolve().parents[1]
source=fingerprint(REPO);snapshot=fingerprint(ROOT/'snapshot')
start=json.loads((ROOT/'preparation/environment-start.json').read_text())
expected=json.loads((ROOT/'preparation/source-start-manifest.json').read_text())
assert source['manifest']==snapshot['manifest']==expected,'source/generated/dependencies changed'
external=json.loads((ROOT/'preparation/external-dependency-start.json').read_text())
p=Path(external['root']);actual={str(f.relative_to(p)):{'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size} for f in p.rglob('*') if f.is_file()}
assert actual==external['manifest'],'external optional dependency changed'
nodehash=hashlib.sha256(Path(start['nodeExecutable']).read_bytes()).hexdigest();assert nodehash==start['nodeExecutableSha256']
runtime={'node':subprocess.check_output(['node','--version']).decode().strip(),'bun':subprocess.check_output(['/home/dev/.local/share/mise/installs/bun/1.4.2/bin/bun','--version']).decode().strip(),'git':subprocess.check_output(['git','--version']).decode().strip(),'python':subprocess.check_output(['python','--version']).decode().strip()}
assert runtime==start['versions']
end={'finishedAt':datetime.now(timezone.utc).isoformat(),'fingerprint':{k:v for k,v in source.items() if k!='manifest'},'sourceGeneratedInstalledDependenciesEqualStartAndSnapshot':True,'externalDependencyEqualStart':True,'externalDependencyRoot':str(p),'externalManifestSha256':hashlib.sha256(json.dumps(actual,sort_keys=True).encode()).hexdigest(),'externalFiles':len(actual),'nodeExecutableEqualStart':True,'versions':runtime,'heapSizeLimitBytes':int(subprocess.check_output(['node','-e',"console.log(require('node:v8').getHeapStatistics().heap_size_limit)"]).decode().strip())}
(ROOT/'preparation/environment-end.json').write_text(json.dumps(end,indent=2)+'\n');print(json.dumps(end))
