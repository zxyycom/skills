"""Aggregate completed Node API reads and actual Git batch framing, independently of CPU metrics."""
from pathlib import Path
import json
from oracle import collection,index_name,git,parse,sha
def impact(row,before):
 d=row['domain'];k=row['id'];c=collection(d);C='261001-candidate-1';A='261001-record-09001';B='261001-record-09002';Z='261001-record-10000';P='261001-record-08001'
 ids=set()
 if k=='publish-predecessor' and d=='decision':ids={A}
 elif k=='discard-formal':ids={Z}
 elif k=='evolve-discard':ids={A,B,Z}
 elif k=='rename-formal':ids={P,A}
 elif k=='rename-formal-owner':ids={'261001-record-00001','261001-record-01001'}
 elif k.startswith('stage-') and k!='stage-index':ids={A if d=='decision' else '261001-record-00001'}
 paths={c+'/'+before['docs'][i]['path'] for i in ids}
 if k.startswith('publish') or k=='bootstrap':paths.add(c+'/'+C+'.md')
 if (k=='publish-predecessor' and d=='decision') or k=='evolve-discard':paths.add(c+'/archive/'+A+'.md')
 if k=='rename-formal':paths.add(c+'/archive/acceptance-renamed.md')
 if k=='rename-formal-owner':paths.add(c+'/acceptance-renamed.md')
 return paths
def historical_dependencies(row,before):
 # Explicit root-confirmed historical identity obligation; NOT current FS permission.
 if row['domain']=='investigation' and row['id']=='publish-predecessor':
  target='261001-record-09999'
  assert {r['target'] for r in before['docs']['261001-candidate-1']['metadata']['relations']}=={target}
  return {collection(row['domain'])+'/'+before['index']['entries'][target]['sourcePath']:target}
 return {}
def category(p,row,before):
 c=collection(row['domain']);rel=str(p)
 if rel==c+'/'+index_name(row['domain']):return 'index'
 if rel.startswith(c+'/_resources/'):return 'resource'
 if rel.startswith(c+'/_candidate.') or rel in {c+'/'+v['path'] for v in before['docs'].values() if v['metadata'].get('status')=='candidate'}:return 'candidate'
 if rel.startswith(c+'/') and rel.endswith('.md'):return 'formal'
 return 'other'
def configuration(row,root,before,output):
 root=Path(root);output=Path(output);c=collection(row['domain'])
 selected=impact(row,before);historical=historical_dependencies(row,before);roles={}
 def add(oid,role):roles.setdefault(role,set()).add(oid)
 for line in git(root,'ls-tree','-r','-z','HEAD').split(b'\0'):
  if not line:continue
  meta,p=line.split(b'\t',1);mode,kind,oid=meta.decode().split();p=p.decode();cat=category(p,row,before)
  if cat=='formal':label='selected-formal' if p in selected else 'selected-history-dependency' if p in historical else 'unselected-formal'
  elif cat=='resource':
   label='selected-resource' if row['domain']=='investigation' and (row['id']=='rename-formal-owner' and '/261001-record-00001/' in p or row['id'].startswith('stage-') and row['id']!='stage-index' and '/261001-record-00001/' in p) else 'unselected-resource'
  else:label=cat
  add(oid,'head:'+label)
 for p,v in before['pending'].items():
  cat=category(p,row,before)
  if cat=='formal':label='selected-formal' if p in selected else 'selected-history-dependency' if p in historical else 'unselected-formal'
  elif cat=='resource':
   label='selected-resource' if row['domain']=='investigation' and row['id']!='stage-index' and '/261001-record-00001/' in p and (row['id']=='rename-formal-owner' or row['id'].startswith('stage-')) else 'unselected-resource'
  else:label=cat
  add(v['oid'],'pending:'+label)
 candidates=[str(root/c/v['path']) for v in before['docs'].values() if v['metadata'].get('status')=='candidate' or v['path'].startswith('_candidate.')]
 # Default new identity under current UTC day; register both domains' actual canonical path.
 import datetime
 i=datetime.datetime.now(datetime.timezone.utc).strftime('%y%m%d')+'-acceptance-new'
 candidates.append(str(root/c/(i+'.md' if row['domain']=='decision' else '_candidate.'+i)))
 resources=[str(root/c/'_resources')]
 return {'outputDir':str(output),'collectionRoot':str(root/c),'indexFile':str(root/c/index_name(row['domain'])),'candidatePaths':candidates,'resourceRoots':resources,'gitObjectRoles':{k:sorted(v) for k,v in roles.items()}}
def summarize(row,root,before,after,output):
 events=[json.loads(line) for file in Path(output).glob('*.events.jsonl') for line in file.read_text().splitlines()]
 reads=[e['value'] for e in events if e['type']=='io' and e['value']['direction']=='read']
 result={'reads':{},'gitBatches':[],'threads':sum(e['type']=='start' for e in events),'threadsEnded':sum(e['type']=='end' for e in events),'unknown':[v for e in events if e['type']=='end' for v in e['value']['unknown']],'counts':{}}
 allowed=impact(row,before)
 # Any new locator written by selected rename is allowed without permitting other members.
 if row['id'].startswith('rename'):
  for i,v in after['docs'].items():
   if i=='261001-acceptance-renamed':allowed.add(collection(row['domain'])+'/'+v['path'])
 candidates={collection(row['domain'])+'/'+v['path'] for v in before['docs'].values() if v['metadata'].get('status')=='candidate' or v['path'].startswith('_candidate.')}
 for v in after['docs'].values():
  if v['metadata'].get('status')=='candidate' or v['path'].startswith('_candidate.'):candidates.add(collection(row['domain'])+'/'+v['path'])
 formal_paths=set();resource_paths=set()
 for read in reads:
  try:relative=Path(read['path']).relative_to(root).as_posix()
  except ValueError:continue
  cat=read['category'] if read['category'] in ['formal','candidate','index','resource'] else category(relative,row,before)
  group=result['reads'].setdefault(cat,{'calls':0,'bytes':0,'paths':set()})
  group['calls']+=read['calls'];group['bytes']+=read['bytes'];group['paths'].add(relative)
  if cat=='formal':formal_paths.add(relative)
  if cat=='resource':resource_paths.add(relative)
 for cat,group in result['reads'].items():
  group['unique']=len(group['paths']);group['paths']=sorted(group['paths'])
 for e in events:
  if e['type']=='git' and e['value']['batch']:result['gitBatches'].append(e['value'])
  if e['type']=='count':
   n=e['value']['name'];result['counts'][n]=result['counts'].get(n,0)+e['value']['amount']
 bad_git=[];blob_count=0;payload=0;index_count=0;formal_count=0;history_count=0
 historical={}
 for p,identity in historical_dependencies(row,before).items():
  entries=git(root,'ls-tree','-z','HEAD','--',p).split(b'\0')
  entry=next(v for v in entries if v);meta,name=entry.split(b'\t',1)
  mode,kind,oid=meta.decode().split();assert kind=='blob' and name.decode()==p
  raw=git(root,'cat-file','blob',oid);assert parse(raw)[0]['id']==identity
  historical[oid]={'path':p,'identity':identity,'oid':oid,'bytes':len(raw),'sha256':sha(raw),'scope':'explicit direct predecessor historical identity'}

 for batch in result['gitBatches']:
  assert 'error' not in batch['batch'],batch
  for b in batch['batch']['blobs']:
   blob_count+=1;payload+=b['bytes']
   roles=b['roles']
   if b['oid'] in historical:
    witness=historical[b['oid']];assert witness['bytes']==b['bytes']
    b['historicalDependencyMembership']=witness
    roles=sorted(set(roles+['scope:selected-history-dependency']))
    b['effectiveRoles']=roles
   if roles==['unknown']:
    # A successful stage may read back newly written selected blobs/indexes.
    # Resolve only from the independently captured complete final P identity map.
    posterior=[]
    for p,v in after['pending'].items():
     if v['oid']!=b['oid']:continue
     assert v['bytes']==b['bytes'],'posterior Git size differs'
     cat=category(p,row,before)
     if cat=='formal':label='selected-formal' if p in allowed else 'unselected-formal'
     elif cat=='resource':
      selected_owner=row['domain']=='investigation' and row['id'].startswith('stage-') and row['id']!='stage-index' and '/261001-record-00001/' in p
      label='selected-resource' if selected_owner else 'unselected-resource'
     else:label=cat
     posterior.append({'path':p,'role':'post:'+label,'oid':v['oid'],'sha256':v['sha256'],'bytes':v['bytes']})
    if posterior:
     b['posteriorMembership']=posterior
     roles=sorted(set(v['role'] for v in posterior))
     b['effectiveRoles']=roles
   if any(':unselected-formal' in r or ':unselected-resource' in r for r in roles) and not any(':selected-' in r for r in roles):bad_git.append(b)
   if any(r.endswith(':index') for r in roles):index_count+=1
   if any(r.endswith(':selected-formal') for r in roles):formal_count+=1
   if any(r.endswith(':selected-history-dependency') for r in roles):history_count+=1
   if roles==['unknown']:bad_git.append(b)
 result['git']={'batches':len(result['gitBatches']),'blobs':blob_count,'payloadBytes':payload,'indexBlobReads':index_count,'selectedFormalBlobReads':formal_count,'historicalDependencyBlobReads':history_count,'unselectedOrUnknown':bad_git,'initiallyUnclassifiedResolvedFromFinalPending':sum('posteriorMembership' in b for batch in result['gitBatches'] for b in batch['batch']['blobs'])}
 bad_formal=sorted(formal_paths-allowed)
 bad_resource=[]
 for p in resource_paths:
  owner=p.split('/_resources/',1)[1].split('/',1)[0]
  accepted=(row['id']=='discard-candidate-owner' and owner=='261001-candidate-2') or (row['id']=='rename-formal-owner' and owner in ['261001-record-00001','261001-acceptance-renamed']) or (row['id'].startswith('stage-') and row['id']!='stage-index' and owner=='261001-record-00001')
  if not accepted:bad_resource.append(p)
 result['boundary']={'unrelatedFormalReads':bad_formal,'unrelatedResourceReads':bad_resource,'unrelatedOrUnclassifiedGitPayload':bad_git,'status':'passed' if not bad_formal and not bad_resource and not bad_git else 'failed'}
 return result
