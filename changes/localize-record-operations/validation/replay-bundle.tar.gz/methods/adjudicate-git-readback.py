from pathlib import Path
from datetime import datetime,timezone
import json
from oracle import capture,summary,sha,verify_effect
from workload import summarize
ROOT=Path(__file__).resolve().parents[1]
original=json.loads((ROOT/'observations.jsonl').read_text().splitlines()[-1])
assert original['domain']=='decision' and original['scenario']=='stage-all' and original['mode']=='instrumented' and original['status']=='failed'
row=next(x for x in json.loads((ROOT/'preparation/matrix.json').read_text()) if x['domain']==original['domain'] and x['id']==original['scenario'])
root=ROOT/'working/decision-stage-all';out=Path(original['rawDirectory'])
before=capture(ROOT/'fixtures/decision-stage-all','decision');after=capture(root,'decision')
for label,state in [('before',before),('after',after)]:
 assert json.loads((out/(label+'-manifest.json')).read_text())=={'files':state['files'],'pending':state['pending']}
 assert summary(state)==original[label]
corrected=dict(original);corrected['effect']=verify_effect(row,root,before,after);corrected['workload']=summarize(row,root,before,after,out/'probe')
assert corrected['workload']['boundary']['status']=='passed',corrected['workload']['boundary']
corrected['status']='passed';corrected.pop('error');corrected.pop('traceback')
corrected['adjudication']='Resolve initial unknown newly written blob OIDs through independent complete final P paths/SHA/size; same original probe/state/events; no rerun'
record={'originalObservationSha256':sha(json.dumps(original,ensure_ascii=False).encode()),'timestamp':datetime.now(timezone.utc).isoformat(),'methodCorrection':json.loads((ROOT/'workload-git-correction.json').read_text()),'correctedObservation':corrected}
with (ROOT/'adjudications.jsonl').open('a') as f:f.write(json.dumps(record,ensure_ascii=False)+'\n')
print(json.dumps({'status':corrected['status'],'formal':corrected['workload']['reads'].get('formal'),'git':corrected['workload']['git'],'probeReexecuted':False}))
