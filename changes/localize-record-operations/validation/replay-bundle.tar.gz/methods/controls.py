"""Untimed contract controls; retain all output and whole W/P identities."""
from pathlib import Path
from datetime import datetime,timezone
import copy,json,os,shutil,subprocess
import oracle
_original_parse=oracle.parse
def permissive_parse(raw):
 try:return _original_parse(raw)
 except Exception:return {'id':'<known-invalid-control-source>','status':'candidate'},raw.decode()
oracle.parse=permissive_parse
from oracle import capture,summary,delta,stable,sha,collection,index_name,projection,verify_effect,verify_index,git
ROOT=Path(__file__).resolve().parents[1];MATRIX=json.loads((ROOT/'preparation/matrix.json').read_text())
os.environ['PATH']='/home/dev/.local/share/mise/installs/bun/1.4.2/bin:'+os.environ['PATH']
os.environ['GIT_CONFIG_GLOBAL']='/dev/null';os.environ['GIT_CONFIG_NOSYSTEM']='1'
ENV=dict(os.environ,NODE_OPTIONS='');RESULTS=[]
def fixture(d,key,name):
 p=ROOT/'controls'/name
 shutil.copytree(ROOT/'fixtures'/(d+'-'+key),p)
 return p
def execute(d,name,root,args,before,expected,checker):
 out=ROOT/'controls-evidence'/name;out.mkdir(parents=True)
 entry=ROOT/'snapshot/skills'/('decision-records/scripts/decision-records.ts' if d=='decision' else 'investigation-report/scripts/check-investigations.ts')
 argv=['node',str(entry),'--root',str(root),*args]
 started=datetime.now(timezone.utc).isoformat();run=subprocess.run(argv,cwd=root,env=ENV,capture_output=True)
 for label,data in [('stdout',run.stdout),('stderr',run.stderr)]:(out/label).write_bytes(data)
 after=capture(root,d)
 result={'domain':d,'control':name,'argv':argv,'expectedExit':expected,'exitCode':run.returncode,'startedAt':started,'before':summary(before),'after':summary(after),'stdout':{'bytes':len(run.stdout),'sha256':sha(run.stdout)},'stderr':{'bytes':len(run.stderr),'sha256':sha(run.stderr)},'status':'failed'}
 try:
  assert run.returncode==expected,(run.returncode,run.stderr.decode())
  result['effect']=checker(before,after);result['status']='passed'
 except Exception as error:result['error']=str(error)
 RESULTS.append(result);(out/'result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 print(name,result['status'],result.get('error',''),flush=True)
 assert result['status']=='passed',result
 return after
def unchanged(before,after):
 assert before['files']==after['files'] and before['pending']==after['pending'] and before['head']==after['head']
 return {'wholeWorktreePendingHead':'unchanged'}
for d in ['decision','investigation']:
 c=collection(d);idxpath=c+'/'+index_name(d)
 # Corrupt an unrelated formal source; local publish must not read or repair it.
 name=d+'-unselected-corrupt';root=fixture(d,'publish-independent',name)
 z=root/c/('archive/261001-record-05005.md' if d=='decision' else '261001-record-05005.md')
 z.write_bytes(b'CORRUPT_UNSELECTED_SOURCE\n');before=capture(root,d)
 def local_publish(b,a):
  C='261001-candidate-1';assert C in a['index']['entries']
  allowed={idxpath,c+'/'+b['docs'][C]['path'],c+'/'+a['docs'][C]['path']}
  assert set(delta(b['files'],a['files']))<=allowed
  assert b['pending']==a['pending'] and b['head']==a['head']
  old=copy.deepcopy(a['index']);del old['entries'][C];del old['sourceRevision']['entries'][C];assert old==b['index']
  assert a['docs'][C]['body']==b['docs'][C]['body']
  i,entry,rev=projection(d,a['docs'][C]['path'],a['raws'][c+'/'+a['docs'][C]['path']])
  assert a['index']['entries'][C]==entry and a['index']['sourceRevision']['entries'][C]==rev
  rel=z.relative_to(root).as_posix();assert a['files'][rel]==b['files'][rel]
  return {'selectedPublication':'passed','unselectedCorruption':'byte/mode unchanged','unselectedPublishedIndex':'unchanged','selectedProjectionRevision':'passed','P/HEAD':'unchanged'}
 args=['publish','261001-candidate-1']+(['--alignment','unaligned'] if d=='decision' else [])
 execute(d,name,root,args,before,0,local_publish)
 # The same ordinary operation must reject a selected source not matching its published revision.
 name=d+'-selected-drift';root=fixture(d,'discard-formal',name);p=root/c/'261001-record-10000.md'
 p.write_bytes(p.read_bytes()+b'\nUNSYNCED_SELECTED_DRIFT\n');before=capture(root,d)
 execute(d,name,root,['discard','261001-record-10000','--delete-recorded'],before,1,unchanged)
 # Legacy location and older date with identical name do not force migration.
 name=d+'-legacy-crossday-new';root=fixture(d,'new',name);idxfile=root/idxpath;idx=json.loads(idxfile.read_text())
 old='261001-record-00001';oldpath=root/c/idx['entries'][old]['sourcePath']
 legacy=oldpath.parent/'legacy-record-00001.md';oldpath.rename(legacy)
 _,entry,rev=projection(d,legacy.relative_to(root/c).as_posix(),legacy.read_bytes())
 idx['entries'][old]=entry;idx['sourceRevision']['entries'][old]=rev;idxfile.write_text(json.dumps(idx,ensure_ascii=False,indent=2)+'\n')
 before=capture(root,d);verify_index(root,d,before)
 row=next(x for x in MATRIX if x['domain']==d and x['id']=='new');args=list(row['argv']);args[1]='record-00001'
 def new_identity(b,a):
  added=set(a['docs'])-set(b['docs']);assert len(added)==1;i=next(iter(added));assert i!='261001-record-00001' and i.endswith('-record-00001')
  expected=i+'.md' if d=='decision' else '_candidate.'+i;assert a['docs'][i]['path']==expected
  assert b['index']==a['index'] and b['pending']==a['pending'] and b['head']==a['head']
  assert delta(b['files'],a['files'])==[c+'/'+expected]
  return {'newIdentity':i,'canonicalLocator':expected,'oldLegacySource':'unchanged','index/P/HEAD':'unchanged'}
 after=execute(d,name,root,args,before,0,new_identity)
 execute(d,d+'-same-day-collision',root,args,after,1,unchanged)
 # Use preserved post-rename state: unselected stale candidate was not auto-repaired.
 name=d+'-stale-candidate-publish';source=ROOT/'working'/(d+('-rename-formal' if d=='decision' else '-rename-formal-owner'))
 root=ROOT/'controls'/name;shutil.copytree(source,root);before=capture(root,d)
 args=['publish','261001-candidate-1']+(['--alignment','unaligned'] if d=='decision' else [])
 execute(d,name,root,args,before,1,unchanged)
(ROOT/'controls-results.json').write_text(json.dumps(RESULTS,ensure_ascii=False,indent=2)+'\n')
print('10 untimed controls passed',flush=True)
