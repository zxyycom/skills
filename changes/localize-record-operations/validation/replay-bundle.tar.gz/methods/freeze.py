"""Freeze source, generated public entrypoints, and installed dependencies without installing."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess
ROOT=Path(__file__).resolve().parents[1];REPO=Path('/workspace/skills')
PATH='/home/dev/.local/share/mise/installs/bun/1.4.2/bin:'+os.environ['PATH']
def identity(p):
 if p.is_symlink():return {'symlink':os.readlink(p)}
 return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':p.stat().st_mode&0o777}
paths=['tools/decision-records','tools/investigation-report','tools/record-operations','tools/index-runtime','tools/shared','skills/decision-records','skills/investigation-report','scripts/build/decision-records.ts','scripts/build/investigation-report.ts','scripts/build/shared.ts','package.json','pnpm-lock.yaml','node_modules']
def fingerprint(base):
 out={}
 for rel in paths:
  p=base/rel
  if not p.exists():continue
  if p.is_dir():
   for directory,names,files in os.walk(p,followlinks=False):
    for n in names+files:
     f=Path(directory)/n
     if f.is_symlink() or f.is_file():out[str(f.relative_to(base))]=identity(f)
  else:out[rel]=identity(p)
 return {'files':len(out),'sha256':hashlib.sha256(json.dumps(out,sort_keys=True).encode()).hexdigest(),'manifest':out}
if __name__=='__main__':
 snapshot=ROOT/'snapshot';snapshot.mkdir()
 before=fingerprint(REPO)
 (ROOT/'preparation/source-start-manifest.json').write_text(json.dumps(before['manifest'],sort_keys=True)+'\n')
 for rel in paths:
  source=REPO/rel
  if not source.exists():continue
  target=snapshot/rel;target.parent.mkdir(parents=True,exist_ok=True)
  if source.is_dir():shutil.copytree(source,target,symlinks=True)
  else:shutil.copy2(source,target)
 after=fingerprint(REPO);frozen=fingerprint(snapshot)
 assert before==after==frozen,'Freeze changed or copied incorrectly'
 env={'startedAt':datetime.now(timezone.utc).isoformat(),'source':str(REPO),'snapshot':str(snapshot),'fingerprint':{k:v for k,v in before.items() if k!='manifest'},'versions':{}}
 for k,args in [('node',['node','--version']),('bun',['bun','--version']),('git',['git','--version']),('python',['python','--version'])]:
  env['versions'][k]=subprocess.check_output(args,env=dict(os.environ,PATH=PATH),stderr=subprocess.STDOUT).decode().strip()
 env['platform']=subprocess.check_output(['uname','-a']).decode().strip()
 env['cgroup']={str(p):p.read_text().strip() for p in [Path('/sys/fs/cgroup/cpu.max'),Path('/sys/fs/cgroup/memory.max')] if p.exists()}
 env['nodeExecutable']=shutil.which('node');env['nodeExecutableSha256']=hashlib.sha256(Path(shutil.which('node')).read_bytes()).hexdigest()
 (ROOT/'preparation/environment-start.json').write_text(json.dumps(env,indent=2)+'\n')
 print(json.dumps(env))
