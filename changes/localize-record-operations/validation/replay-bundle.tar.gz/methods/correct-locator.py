"""Root-approved correction of the handoff locator expectation; no CLI is rerun."""
from pathlib import Path
from datetime import datetime,timezone
import json
from oracle import sha
ROOT=Path(__file__).resolve().parents[1]
changes=[]
for rel,old,new in [
 ('methods/oracle.py',"'_candidate.'+i+'/'+i+'.md'","'_candidate.'+i"),
 ('methods/workload.py',"'_candidate.'+i+'/'+i+'.md'","'_candidate.'+i"),
 ('methods/controls.py',"'_candidate.'+i+'/'+i+'.md'","'_candidate.'+i")]:
 p=ROOT/rel;before=p.read_bytes();s=before.decode();assert old in s
 s=s.replace(old,new);p.write_text(s)
 changes.append({'file':rel,'beforeSha256':sha(before),'afterSha256':sha(p.read_bytes()),'exactBefore':old,'exactAfter':new})
p=ROOT/'preparation/matrix.json';before=p.read_bytes();rows=json.loads(before)
row=next(x for x in rows if x['domain']=='investigation' and x['id']=='new')
old=row['expected'];row['expected']='full ID flat _candidate.<id> file;formal/index/pending unchanged'
p.write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
changes.append({'file':'preparation/matrix.json','beforeSha256':sha(before),'afterSha256':sha(p.read_bytes()),'exactBefore':old,'exactAfter':row['expected']})
correction={'timestamp':datetime.now(timezone.utc).isoformat(),'kind':'method-only handoff expectation correction','authorization':'root confirmed IR owner specifies flat _candidate.<full ID>; do not rerun or replace sample','affectedSample':{'domain':'investigation','scenario':'new','iteration':1,'mode':'normal'},'changes':changes,'sourceGeneratedDependencyChanges':False,'rerun':False}
(ROOT/'method-correction.json').write_text(json.dumps(correction,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(correction))
