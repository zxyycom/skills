"""Preserve invalid-input evidence, repair only selected IR stage source location/revision."""
from pathlib import Path
from datetime import datetime,timezone
import json
from oracle import capture,summary,verify_index,sha,projection
ROOT=Path(__file__).resolve().parents[1]
observations=[json.loads(x) for x in (ROOT/'observations.jsonl').read_text().splitlines()]
original=observations[-1];assert original['domain']=='investigation' and original['scenario']=='stage-all' and original['status']=='failed'
out=Path(original['rawDirectory'])
b=json.loads((out/'before-manifest.json').read_text());a=json.loads((out/'after-manifest.json').read_text());assert b==a,'invalid-input refusal wrote state'
repairs=[]
for scope in ['all','domain','index']:
 root=ROOT/'fixtures'/('investigation-stage-'+scope);c=root/'docs/investigations';source=c/'261001-record-00001.md';index=c/'investigation-index.json'
 old=source.read_bytes();(ROOT/'preparation'/('invalid-stage-'+scope+'-selected.md')).write_bytes(old)
 idx=json.loads(index.read_text());old_index_sha=sha(index.read_bytes());oldrev=idx['sourceRevision']['entries']['261001-record-00001']
 text=old.decode();assert text.endswith('\nSELECTED_CURRENT_A\n')
 text=text.removesuffix('\nSELECTED_CURRENT_A\n').replace('## 随附资源','SELECTED_CURRENT_A\n\n## 随附资源')
 source.write_text(text);i,entry,rev=projection('investigation','261001-record-00001.md',source.read_bytes())
 idx['entries'][i]=entry;idx['sourceRevision']['entries'][i]=rev
 index.write_text(json.dumps(idx,ensure_ascii=False,indent=2)+'\n')
 state=capture(root,'investigation');proof=verify_index(root,'investigation',state)
 repairs.append({'scope':scope,'sourceBeforeSha256':sha(old),'sourceAfterSha256':sha(source.read_bytes()),'indexBeforeSha256':old_index_sha,'indexAfterSha256':sha(index.read_bytes()),'revisionBefore':oldrev,'revisionAfter':rev,'afterState':summary(state),'oracle':proof})
record={'timestamp':datetime.now(timezone.utc).isoformat(),'classification':'method-invalid-input','originalObservationSha256':sha(json.dumps(original,ensure_ascii=False).encode()),'originalProcessReexecuted':False,'originalZeroWriteVerified':True,'authority':'IR attached-resource section accepts local inline resource links, not arbitrary appended body text','correction':'move SELECTED_CURRENT_A before attached-resource heading; recalculate only selected sourceRevision','preparationScope':'Original independent preparation proved projection/revision/resource references, not all body-section grammar','replacementPolicy':'keep all original bytes/metrics; add one valid stage-all sample; 93 total CLI measurement processes for 92 accepted observations','repairs':repairs}
(ROOT/'invalidations.jsonl').write_text(json.dumps(record,ensure_ascii=False)+'\n')
print(json.dumps({'classification':record['classification'],'zeroWrite':True,'scopesRepaired':len(repairs)}))
