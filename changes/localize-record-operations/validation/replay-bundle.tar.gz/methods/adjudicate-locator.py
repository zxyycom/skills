"""Append posterior adjudication on the original unmodified process result/state."""
from pathlib import Path
import json
import run
from oracle import capture,summary,verify_effect,sha
ROOT=Path(__file__).resolve().parents[1]
observations=[json.loads(x) for x in (ROOT/'observations.jsonl').read_text().splitlines()]
original=observations[-1];assert original['status']=='failed' and original['scenario']=='new' and original['domain']=='investigation'
row=next(x for x in run.MATRIX if x['domain']=='investigation' and x['id']=='new')
root=ROOT/'working/investigation-new';out=Path(original['rawDirectory'])
before=capture(ROOT/'fixtures/investigation-new','investigation');after=capture(root,'investigation')
for label,s in [('before',before),('after',after)]:
 saved=json.loads((out/(label+'-manifest.json')).read_text())
 assert saved=={'files':s['files'],'pending':s['pending']},label+' state changed since original sample'
 assert summary(s)==original[label]
corrected=dict(original);corrected['effect']=verify_effect(row,root,before,after)
corrected['normalizedState'],corrected['normalization']=run.normalized(row,before,after)
corrected['outputEqualityKey']=[original['metrics']['stdout']['sha256'],original['metrics']['stderr']['sha256']]
corrected['status']='passed';corrected['adjudication']='root-approved method expectation correction; same original CLI result and byte-identical after-state; no rerun'
corrected.pop('error');corrected.pop('traceback')
value={'originalObservationSha256':sha(json.dumps(original,ensure_ascii=False).encode()),'methodCorrectionSha256':sha((ROOT/'method-correction.json').read_bytes()),'correctedObservation':corrected}
(ROOT/'adjudications.jsonl').write_text(json.dumps(value,ensure_ascii=False)+'\n')
print(json.dumps({'status':corrected['status'],'effect':corrected['effect'],'processReexecuted':False,'wall':corrected['metrics']['wallSeconds']}))
