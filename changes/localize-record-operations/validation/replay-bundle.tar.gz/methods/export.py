"""Export compact auditable evidence; raw large manifests/dependencies remain outside Git."""
from pathlib import Path
from datetime import datetime,timezone
import csv,gzip,hashlib,io,json,statistics,tarfile
from oracle import sha,delta,stable
ROOT=Path(__file__).resolve().parents[1]
DEST=Path('/workspace/skills/changes/localize-record-operations/validation')
def read(path):return json.loads((ROOT/path).read_text())
def lines(path):return [json.loads(x) for x in (ROOT/path).read_text().splitlines()]
def dump(name,value): (DEST/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def jsonl(name,values):(DEST/name).write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in values))
raw=lines('observations.jsonl');amendments=lines('adjudications.jsonl');invalidations=lines('invalidations.jsonl')
def key(x):return (x['domain'],x['scenario'],x['iteration'],x['mode'])
amended={key(x['correctedObservation']):x['correctedObservation'] for x in amendments}
invalid={x['originalObservationSha256'] for x in invalidations}
assert len(raw)==93 and len({x['rawDirectory'] for x in raw})==93
effective=[];samples=[];effects=[];workloads=[];assets={}
def remember(path,expected=None):
 data=Path(path).read_bytes();h=sha(data)
 if expected:assert h==expected['sha256'] and len(data)==expected['bytes']
 assets.setdefault(h,data)
 return {'sha256':h,'bytes':len(data),'bundlePath':'streams/'+h+'.txt'}
for original in raw:
 rawhash=sha(json.dumps(original,ensure_ascii=False).encode());bad=rawhash in invalid
 result=amended.get(key(original),original)
 if not bad:assert result['status']=='passed';effective.append(result)
 sample_id=Path(original['rawDirectory']).relative_to(ROOT/'runs').as_posix()
 sample={k:original[k] for k in ['domain','scenario','iteration','mode','metrics','before','after','status']}
 sample.update(observationId=sample_id,originalRecordSha256=rawhash,accepted=not bad,classification='method-invalid-input' if bad else 'accepted-after-method-correction' if original['status']=='failed' else 'accepted')
 if 'error' in original:sample['originalVerificationError']=original['error']
 if not bad:
  sample['normalizedState']=result['normalizedState'];sample['normalization']=result['normalization']
  sample['effectiveVerification']='passed'
 for stream in ['stdout','stderr']:
  sample['metrics'][stream]['bundlePath']=remember(original['metrics'][stream]['path'],original['metrics'][stream])['bundlePath']
 samples.append(sample)
 out=Path(original['rawDirectory']);before=read(out.relative_to(ROOT)/'before-manifest.json');after=read(out.relative_to(ROOT)/'after-manifest.json')
 change={}
 for part in ['files','pending']:
  change[part]=[{'path':p,'before':before[part].get(p),'after':after[part].get(p)} for p in delta(before[part],after[part])]
 effects.append({'observationId':sample_id,'accepted':not bad,'independentEffect':result.get('effect') if not bad else {'completeW/P':'unchanged','expectedInputValidity':'invalid attached-resource section'},'delta':change,'rawBeforeManifest':{'bytes':(out/'before-manifest.json').stat().st_size,'sha256':sha((out/'before-manifest.json').read_bytes())},'rawAfterManifest':{'bytes':(out/'after-manifest.json').stat().st_size,'sha256':sha((out/'after-manifest.json').read_bytes())}})
 if result['mode']=='instrumented' and not bad:workloads.append({'observationId':sample_id,'domain':result['domain'],'scenario':result['scenario'],**result['workload']})
assert len(effective)==92 and sum(x['mode']=='normal' for x in effective)==69 and len(workloads)==23
assert len({key(x) for x in effective})==92
matrix=read('preparation/matrix.json');summaries=[]
for row in matrix:
 group=[x for x in effective if x['domain']==row['domain'] and x['scenario']==row['id']]
 normals=[x for x in group if x['mode']=='normal'];probes=[x for x in group if x['mode']=='instrumented']
 assert len(normals)==3 and len(probes)==1
 assert len({x['normalizedState']['worktreeSha256'] for x in group})==1 and len({x['normalizedState']['pendingSha256'] for x in group})==1
 assert len({(x['metrics']['stdout']['sha256'],x['metrics']['stderr']['sha256']) for x in group})==1
 stats={}
 for field in ['wallSeconds','cpuSeconds','maxRssKiB']:
  values=[x['metrics'][field] for x in normals];stats[field]={'min':min(values),'median':statistics.median(values),'max':max(values)}
 probe=probes[0];assert probe['workload']['boundary']['status']=='passed'
 summaries.append({'domain':row['domain'],'scenario':row['id'],'formalCount':row['formalCount'],'expectedExit':row['expectedExit'],'normal':stats,'probeMetrics':{k:probe['metrics'][k] for k in ['wallSeconds','cpuSeconds','maxRssKiB']},'workload':{'reads':probe['workload']['reads'],'git':probe['workload']['git']},'outputsAndNormalizedStateEqual':True})
controls=read('controls-results.json');assert len(controls)==10 and all(c['status']=='passed' for c in controls)
for c in controls:
 for stream in ['stdout','stderr']:
  c[stream]['bundlePath']=remember(ROOT/'controls-evidence'/c['control']/stream,c[stream])['bundlePath']
DEST.mkdir(exist_ok=False)
dump('matrix.json',matrix);jsonl('samples.jsonl',samples);jsonl('effects.jsonl',effects);jsonl('workloads.jsonl',workloads);dump('controls.json',controls);dump('summary.json',summaries)
cancelled=read('preparation/cli/investigation-initial-check.json')
cancelled.update(classification='untimed preparation command cancelled by owner; excluded from 93 measurements',observedElapsed='approximately 3m25s; no wait4 measurement collected',stdout=remember(ROOT/'preparation/cli/investigation-initial-check.stdout'),stderr=remember(ROOT/'preparation/cli/investigation-initial-check.stderr'))
dump('corrections.json',{'locatorExpectation':read('method-correction.json'),'sameOriginalStateAdjudication':amendments,'invalidInput':invalidations,'finalReplayRecipeCorrection':read('fixture-recipe-correction.json'),'replayRecipePreparationCorrection':read('reconstruction-method-correction.json'),'untimedPreparationCancellation':cancelled})
# Bundle only small methods/templates and content-deduplicated complete output streams.
members={}
for p in (ROOT/'methods').rglob('*'):
 if p.is_file() and '__pycache__' not in p.parts and p.suffix in ['.py','.mjs','.md','.txt']:
  members['methods/'+p.relative_to(ROOT/'methods').as_posix()]=p.read_bytes()
for h,data in assets.items():members['streams/'+h+'.txt']=data
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
 for name,data in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644
  archive.addfile(info,io.BytesIO(data))
archive_data=gzip.compress(buffer.getvalue(),mtime=0)
(DEST/'replay-bundle.tar.gz').write_bytes(archive_data)
dump('replay-index.json',{'archive':'replay-bundle.tar.gz','bytes':len(archive_data),'sha256':sha(archive_data),'members':[{'path':name,'bytes':len(data),'sha256':sha(data)} for name,data in sorted(members.items())],'scope':'Methods and exact deduplicated stdout/stderr only; no large fixture, dependency tree, large index or full per-sample maps.'})
provenance={'exportedAt':datetime.now(timezone.utc).isoformat(),'environmentStart':read('preparation/environment-start.json'),'environmentEnd':read('preparation/environment-end.json'),'externalDependencyStart':read('preparation/external-dependency-start.json'),'dependencyResolution':read('preparation/dependency-resolution.json'),'originalTemplates':read('preparation/fixtures.json'),'compactInputReconstruction':read('preparation/reconstruction-proof.json'),'initialScenarioProofs':read('preparation/final-fixtures.json'),'collectorSelfcheck':{'status':'passed','checks':len(read('preparation/collector-selfcheck/audit-results.json')['checks']),'collectorSha256':read('preparation/collector-selfcheck/audit-results.json')['collectorSha256']},'probeSelfcheck':read('preparation/probe-selfcheck/summary.json'),'rawObservations':{'path':str(ROOT/'observations.jsonl'),'bytes':(ROOT/'observations.jsonl').stat().st_size,'sha256':sha((ROOT/'observations.jsonl').read_bytes()),'lines':len(raw)},'audit':{'measuredProcesses':93,'acceptedNormal':69,'acceptedProbe':23,'expectedAcceptedRejections':sum(x['metrics']['exitCode']!=0 for x in effective),'methodInvalidInputProcesses':1,'methodExpectationAdjudicationsWithoutRerun':len(amendments),'untimedControls':10,'allNormalProbeCompleteOutputsEqual':True,'allNormalProbeNormalizedFinalStatesEqual':True,'allWorkloadBoundariesPassed':True,'allExpectedRejectionsZeroWrite':True,'allSourceGeneratedDependenciesUnchanged':True,'noDroppedOrOverwrittenMeasuredProcess':True,'completeOutputStreams':len(raw)*2+len(controls)*2,'uniqueOutputAssets':len(assets)}}
dump('provenance.json',provenance)
print(json.dumps({'directory':str(DEST),'files':len(list(DEST.iterdir())),'bytes':sum(p.stat().st_size for p in DEST.iterdir()),'bundleBytes':len(archive_data),'accepted':len(effective),'raw':len(raw)},ensure_ascii=False))
