"""Initialize Git around compact-recipe inputs; verify byte-identical original template trees."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess
from oracle import sha
ROOT=Path(__file__).resolve().parents[1]
recreated=ROOT/'recreated-inputs';expected=json.loads((ROOT/'preparation/fixtures.json').read_text())
env=dict(os.environ,GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_AUTHOR_DATE='2026-10-01T00:00:00Z',GIT_COMMITTER_DATE='2026-10-01T00:00:00Z')
def manifest(root):
 return {p.relative_to(root).as_posix():{'bytes':p.stat().st_size,'mode':oct(p.stat().st_mode&0o777),'sha256':sha(p.read_bytes())} for p in sorted(root.rglob('*')) if p.is_file() and '.git' not in p.relative_to(root).parts}
proof=[]
for row in expected:
 d=row['domain'];p=recreated/d;m=manifest(p);actual=sha(json.dumps(m,sort_keys=True).encode());assert actual==row['manifestSha256'],(d,actual,row['manifestSha256'])
 def git(*args):return subprocess.check_output(['git','-C',str(p),*args],env=env)
 git('init','-q')
 for k,v in [('core.hooksPath','/dev/null'),('user.name','Acceptance Fixture'),('user.email','fixture@example.invalid')]:git('config',k,v)
 git('add','.');git('commit','-qm','Freeze original 10k acceptance template')
 head=git('rev-parse','HEAD').decode().strip();assert head==row['head'],(d,head,row['head'])
 proof.append({'domain':d,'files':len(m),'manifestSha256':actual,'head':head,'byteModeAndGitHeadExact':True})
 if not (ROOT/'templates'/d).exists():
  (ROOT/'templates').mkdir(exist_ok=True);shutil.move(str(p),str(ROOT/'templates'/d))
(ROOT/'preparation/reconstruction-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
