"""Independent YAML, content-fingerprint, complete W/P oracle; no product imports."""
from pathlib import Path
import hashlib,json,os,re,subprocess,yaml
class Loader(yaml.CSafeLoader):pass
Loader.yaml_implicit_resolvers={k:[(t,p) for t,p in v if t!='tag:yaml.org,2002:timestamp'] for k,v in yaml.CSafeLoader.yaml_implicit_resolvers.items()}
PARSED={};OBJECTS={}
def sha(data):return hashlib.sha256(data).hexdigest()
def stable(value):return sha(json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode())
def git(root,*args,data=None):
 p=subprocess.run(['git','-C',str(root),*args],input=data,capture_output=True)
 if p.returncode:raise RuntimeError((args,p.stderr.decode()))
 return p.stdout
def collection(domain):return 'docs/decisions' if domain=='decision' else 'docs/investigations'
def index_name(domain):return 'decision-index.json' if domain=='decision' else 'investigation-index.json'
def parse(raw):
 key=sha(raw)
 if key not in PARSED:
  text=raw.decode().removeprefix('\ufeff').replace('\r\n','\n').replace('\r','\n')
  assert text.startswith('---\n')
  head,sep,body=text[4:].partition('\n---\n');assert sep
  meta=yaml.load(head,Loader=Loader);assert isinstance(meta,dict) and isinstance(meta['id'],str)
  PARSED[key]=(meta,body)
 return PARSED[key]
def fingerprint(label,*values):
 h=hashlib.sha256((label+'\0').encode())
 for value in values:
  data=value.encode();h.update(str(len(data)).encode()+b':'+data+b'\0')
 return 'sha256:'+h.hexdigest()
def projection(domain,source,raw):
 m,b=parse(raw);identity=m['id']
 fields=('title','status','alignment','createdAt','purpose','background','decision','tags','relations') if domain=='decision' else ('title','formedAt','question','tags','relations')
 entry={k:m[k] for k in fields}
 entry.update(name=identity[7:],sourcePath=source)
 if domain=='investigation':
  entry['resourceIds']=sorted(set(re.findall(r'\]\(\./_resources/([^\s)]+)\)',raw.decode())))
 text=raw.decode().replace('\r\n','\n')
 if domain=='investigation':text=text.replace('\r','\n')
 return identity,entry,fingerprint(('decision' if domain=='decision' else 'investigation')+'-index-entry-v2',identity,source,text)
def capture(root,domain):
 c=collection(domain); files={};docs={};raws={}
 for directory,names,filenames in os.walk(root):
  names[:]=[n for n in names if n!='.git']
  for name in filenames:
   p=Path(directory)/name;assert not p.is_symlink()
   rel=p.relative_to(root).as_posix();data=p.read_bytes();raws[rel]=data
   files[rel]={'sha256':sha(data),'bytes':len(data),'mode':p.stat().st_mode&0o777}
   if rel.startswith(c+'/') and (name.endswith('.md') or name.startswith('_candidate.')):
    m,b=parse(data);i=m['id'];assert i not in docs
    docs[i]={'path':rel[len(c)+1:],'metadata':m,'body':b,'sha256':sha(data)}
 idxraw=raws.get(c+'/'+index_name(domain))
 try:idx=json.loads(idxraw) if idxraw else None
 except ValueError:idx='invalid'
 pending={}
 for row in git(root,'ls-files','--stage','-z').split(b'\0'):
  if not row:continue
  meta,name=row.split(b'\t',1);mode,oid,stage=meta.decode().split();assert stage=='0'
  pending[name.decode()]={'mode':mode,'oid':oid}
 oids=sorted(set(v['oid'] for v in pending.values())-set(OBJECTS))
 if oids:
  batch=git(root,'cat-file','--batch',data=('\n'.join(oids)+'\n').encode());pos=0
  for oid in oids:
   end=batch.index(b'\n',pos);parts=batch[pos:end].decode().split();assert parts[:2]==[oid,'blob']
   n=int(parts[2]);payload=batch[end+1:end+1+n];assert len(payload)==n and batch[end+1+n:end+2+n]==b'\n'
   OBJECTS[oid]={'sha256':sha(payload),'bytes':n};pos=end+2+n
  assert pos==len(batch)
 for value in pending.values():value.update(OBJECTS[value['oid']])
 return {'files':files,'docs':docs,'index':idx,'pending':pending,'head':git(root,'rev-parse','HEAD').decode().strip(),'raws':raws}
def summary(s):
 return {'files':len(s['files']),'worktreeSha256':stable(s['files']),'pendingPaths':len(s['pending']),'pendingSha256':stable(s['pending']),'head':s['head'],'indexSha256':stable(s['index'])}
def delta(left,right):return sorted(k for k in left.keys()|right.keys() if left.get(k)!=right.get(k))
def formal(domain,s):
 return {i:d for i,d in s['docs'].items() if (d['metadata']['status']!='candidate' if domain=='decision' else not d['path'].startswith('_candidate.'))}
def verify_index(root,domain,s):
 fs=formal(domain,s);idx=s['index'];assert isinstance(idx,dict)
 assert idx['schemaVersion']==4 and idx['definitionVersion']==11
 assert idx['namespace']==('decisions' if domain=='decision' else 'investigations')
 assert idx['metadata']=={} and set(idx['entries'])==set(fs)
 label='decision-index-metadata-v2' if domain=='decision' else 'investigation-index-metadata-v4'
 assert idx['sourceRevision']['metadata']==fingerprint(label,'{}')
 assert set(idx['sourceRevision']['entries'])==set(fs)
 for i,d in fs.items():
  identity,entry,rev=projection(domain,d['path'],s['raws'][collection(domain)+'/'+d['path']])
  assert idx['entries'][i]==entry,('projection',i,idx['entries'][i],entry)
  assert idx['sourceRevision']['entries'][i]==rev,('revision',i)
  for rel in entry['relations']:assert rel['target'] in fs,('dangling',i,rel)
  if domain=='decision':assert d['path'].startswith('archive/')==(d['metadata']['status']=='archived')
  else:
   for resource in entry['resourceIds']:assert collection(domain)+'/_resources/'+resource in s['files']
 return {'formal':len(fs),'relations':sum(len(d['metadata']['relations']) for d in fs.values()),'indexAndCompleteSourceRevision':'passed','resourceReferences':'passed' if domain=='investigation' else 'not-applicable'}
def pending_index(root,domain,s):
 p=collection(domain)+'/'+index_name(domain)
 return json.loads(git(root,'cat-file','blob',s['pending'][p]['oid']))
def verify_effect(row,root,before,after):
 d=row['domain'];key=row['id'];c=collection(d);idxpath=c+'/'+index_name(d)
 wd=delta(before['files'],after['files']);pd=delta(before['pending'],after['pending'])
 C='261001-candidate-1';D='261001-candidate-2';A='261001-record-09001';B='261001-record-09002';Z='261001-record-10000';P='261001-record-08001'
 detail={'worktreeChangedPaths':wd,'pendingChangedPaths':pd}
 assert before['head']==after['head'],'HEAD changed'
 if row['expectedExit']:
  assert not wd and not pd,'rejection wrote persistent state'
  return dict(detail,checks=['expected nonzero; complete W/P unchanged'])
 if key.startswith('stage-'):
  assert not wd,'stage changed W'
  scope=key[6:];target=A if d=='decision' else '261001-record-00001'
  selected={c+'/'+before['index']['entries'][target]['sourcePath']}
  if d=='investigation':
   selected|={p for p in before['files'] if p.startswith(c+'/_resources/'+target+'/')}
   # complete owner tree includes HEAD-only stale.txt deletion
   selected|={p for p in before['pending'] if p.startswith(c+'/_resources/'+target+'/')}
  allowed=(selected if scope!='index' else set())|({idxpath} if scope!='domain' else set())
  assert set(pd)<=allowed,('unexpected stage paths',pd,allowed)
  for p in before['pending'].keys()|after['pending'].keys():
   if p not in allowed:assert before['pending'].get(p)==after['pending'].get(p),('unselected pending',p)
  if scope!='index':
   for p in selected:
    if p in before['files']:
     expected=before['files'][p];actual=after['pending'].get(p)
     assert actual and (actual['sha256'],actual['bytes'])==(expected['sha256'],expected['bytes']),(p,'pending bytes')
     assert actual['mode']==('100755' if expected['mode']&0o111 else '100644')
    else:assert p not in after['pending'],('owner stale retained',p)
  if scope!='domain':
   old=pending_index(root,d,before);new=pending_index(root,d,after);expected=json.loads(json.dumps(old))
   for part in ['entries']:
    expected[part][target]=before['index'][part][target]
   expected['sourceRevision']['entries'][target]=before['index']['sourceRevision']['entries'][target]
   assert new==expected,'pending index not exact selected composition'
  else:assert before['pending'][idxpath]==after['pending'][idxpath]
  return dict(detail,checks=['W byte/mode invariant','scope exact selected bytes/index composition','all unselected P identities including deletion/mode/OID invariant'])
 assert not pd,'non-stage changed pending'
 actual=verify_index(root,d,after) if key!='new' else {}
 oldformal=formal(d,before);newformal=formal(d,after)
 allow={idxpath}; changed_ids=set();removed=set();added=set()
 if key=='new':
  added=set(after['docs'])-set(before['docs']);assert len(added)==1
  i=next(iter(added));doc=after['docs'][i];assert re.fullmatch(r'\d{6}-acceptance-new',i)
  assert doc['path']==(i+'.md' if d=='decision' else '_candidate.'+i),doc['path']
  assert before['index']==after['index'];allow={c+'/'+doc['path']}
  detail['createdIdentity']=i;detail['createdLocator']=doc['path']
 elif key.startswith('publish') or key=='bootstrap':
  assert C in newformal and C not in oldformal
  assert newformal[C]['body']==before['docs'][C]['body']
  changed_ids={C}
  if key=='publish-predecessor' and d=='decision':
   changed_ids.add(A);assert newformal[A]['metadata']['status']=='archived'
  assert len(newformal)==row['formalCount']+1
 elif key=='discard-candidate' or key=='discard-candidate-owner':
  target=C if d=='decision' else D
  removed={target};assert target not in after['docs']
  assert before['index']==after['index']
  if d=='investigation':
   owner=c+'/_resources/'+target+'/'
   assert not any(p.startswith(owner) for p in after['files'])
   allow|={p for p in before['files'] if p.startswith(owner)}
 elif key=='discard-formal':
  removed={Z};assert Z not in after['docs'] and len(newformal)==9999
 elif key=='evolve-discard':
  removed={Z};changed_ids={A,B}
  assert len(newformal)==9999 and newformal[A]['metadata']['status']=='archived'
  assert newformal[B]['metadata']['alignment']=='aligned'
  assert newformal[B]['metadata']['relations']==[{'type':'修订','target':A}]
 elif key in ['rename-formal','rename-formal-owner']:
  old=P if d=='decision' else '261001-record-00001'
  new='261001-acceptance-renamed';incoming='261001-record-09001' if d=='decision' else '261001-record-01001'
  assert old not in after['docs'] and new in newformal
  removed={old};added={new};changed_ids={incoming}
  assert any(x['target']==new for x in newformal[incoming]['metadata']['relations'])
  assert not any(rel['target']==old for v in newformal.values() for rel in v['metadata']['relations'])
  if d=='investigation':
   prefix=c+'/_resources/'
   before_owner={p[len(prefix+old+'/'):]:v for p,v in before['files'].items() if p.startswith(prefix+old+'/')}
   after_owner={p[len(prefix+new+'/'):]:v for p,v in after['files'].items() if p.startswith(prefix+new+'/')}
   assert before_owner==after_owner and before_owner
   assert not any(p.startswith(prefix+old+'/') for p in after['files'])
   allow|={p for p in wd if p.startswith(prefix+old+'/') or p.startswith(prefix+new+'/')}
 for i in changed_ids|removed|added:
  if i in before['docs']:allow.add(c+'/'+before['docs'][i]['path'])
  if i in after['docs']:allow.add(c+'/'+after['docs'][i]['path'])
 assert set(wd)<=allow,('unexpected W paths',wd,allow)
 for i in (set(before['docs'])|set(after['docs']))-(changed_ids|removed|added):
  assert before['docs'].get(i)==after['docs'].get(i),('unselected doc changed',i)
 if key not in ['new','discard-candidate','discard-candidate-owner']:
  assert after['index']!=before['index'],'formal operation did not update index'
 detail.update(actual);detail['checks']=['complete W bytes/mode permitted delta','all unselected documents identical','P and HEAD invariant','full index projection/sourceRevision/resource consistency' if actual else 'index/formal invariant']
 return detail
