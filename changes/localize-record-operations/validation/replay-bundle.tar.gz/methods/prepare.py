"""Prepare owned read-only-template copies only; no product CLI is executed."""
from pathlib import Path
import hashlib, io, json, os, subprocess, tarfile
ROOT=Path(__file__).resolve().parents[1]
SOURCE=Path('/tmp/unify-record-operations-baseline/fixture-v3')
HEAD='9fdb438df1f4e33722cf6eb131983ba071930d75'
ENV={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
ENV.update(GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_AUTHOR_DATE='2026-10-01T00:00:00Z',GIT_COMMITTER_DATE='2026-10-01T00:00:00Z')
def git(root,*args):return subprocess.check_output(['git','-C',str(root),*args],env=ENV)
assert git(SOURCE,'rev-parse','HEAD').decode().strip()==HEAD
source_manifest=json.loads((SOURCE/'tree-manifest.json').read_text())
def manifest(root):
 return {str(p.relative_to(root)):{'bytes':p.stat().st_size,'mode':oct(p.stat().st_mode&0o777),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(root.rglob('*')) if p.is_file() and '.git' not in p.relative_to(root).parts}
proof=[]
for domain,collection in [('decision','docs/decisions'),('investigation','docs/investigations')]:
 target=ROOT/'templates'/domain
 target.mkdir(parents=True)
 archive=git(SOURCE,'archive',HEAD,collection)
 with tarfile.open(fileobj=io.BytesIO(archive)) as bundle:bundle.extractall(target,filter='data')
 observed=manifest(target)
 expected={p:v for p,v in source_manifest.items() if p.startswith(collection+'/')}
 # git archive fixes writable permission by umask; compare bytes, SHA and executable bit.
 assert observed.keys()==expected.keys()
 assert all(observed[p]['sha256']==v['sha256'] and observed[p]['bytes']==v['bytes'] and int(observed[p]['mode'],8)&0o111==int(v['mode'],8)&0o111 for p,v in expected.items())
 git(target,'init','-q')
 for k,v in [('core.hooksPath','/dev/null'),('user.name','Acceptance Fixture'),('user.email','fixture@example.invalid')]:git(target,'config',k,v)
 git(target,'add','.')
 git(target,'commit','-qm','Freeze original 10k acceptance template')
 assert not git(target,'remote').strip()
 assert not git(target,'status','--porcelain').strip()
 idx=json.loads((target/collection/('decision-index.json' if domain=='decision' else 'investigation-index.json')).read_text())
 proof.append({'domain':domain,'sourceHead':HEAD,'head':git(target,'rev-parse','HEAD').decode().strip(),'files':len(observed),'formal':len(idx['entries']),'relations':sum(len(v['relations']) for v in idx['entries'].values()),'manifestSha256':hashlib.sha256(json.dumps(observed,sort_keys=True).encode()).hexdigest(),'archiveSha256':hashlib.sha256(archive).hexdigest(),'remotes':[],'hooksPath':'/dev/null','permissionBoundary':'git archive umask may remove group-write; executable bits verified'})
 (ROOT/'preparation'/f'{domain}-template-manifest.json').write_text(json.dumps(observed,sort_keys=True)+'\n')
(ROOT/'preparation'/'fixtures.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps(proof))
