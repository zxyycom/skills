from pathlib import Path
import importlib.util, json, os, sys, time
R=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('audit_collector',R/'methods/collector.py'); c=importlib.util.module_from_spec(spec);sys.modules[spec.name]=c;spec.loader.exec_module(c)
P=R/'preparation'/'collector-selfcheck';P.mkdir(exist_ok=False)
checks=[]
def check(name,value,detail=None):
 checks.append({'name':name,'ok':bool(value),'detail':detail});assert value,name

def run(name,code,timeout=3):
 s=c.parse_measurement({'argv':[sys.executable,'-c',code],'cwd':str(P),'outputPrefix':str(P/name),'timeoutSeconds':timeout,'domain':'audit','scenario':name,'iteration':0,'mode':'collector-selfcheck'})
 return c.run_measurement(s)

x=run('success',"import sys;print('ok');sys.stderr.write('warn\\n')")
check('success-exit-streams-units',x['exitCode']==0 and x['stdout']['bytes']==3 and x['stderr']['bytes']==5 and x['wallSeconds']>0 and x['userSeconds']>=0 and x['systemSeconds']>=0 and x['cpuSeconds']==x['userSeconds']+x['systemSeconds'] and x['maxRssKiB']>0,x)
x=run('nonzero',"import sys;print('failed');sys.exit(7)")
check('nonzero-retained',x['exitCode']==7 and x['stdout']['bytes']==7,x)
x=run('large-output',"import os;os.write(1,b'x'*(1024*1024));os.write(2,b'y'*(512*1024))")
check('untruncated-large-output',x['exitCode']==0 and x['stdout']['bytes']==1048576 and x['stderr']['bytes']==524288,x)
pidfile=P/'child.pid'
code=f"import subprocess,sys,time,pathlib; p=subprocess.Popen([sys.executable,'-c','import time;time.sleep(20)']);pathlib.Path({str(pidfile)!r}).write_text(str(p.pid));time.sleep(20)"
x=run('timeout-group',code,.25)
pid=int(pidfile.read_text()); time.sleep(.05); status=Path(f'/proc/{pid}/status'); alive=status.exists() and '\nState:\tZ' not in status.read_text()
check('timeout-kills-group',x['timedOut'] and x['exitCode']==-9 and not alive,{'metrics':x,'childPid':pid,'childAliveNonZombie':alive})
try: run('success',"raise Exception('must not run')")
except FileExistsError: check('duplicate-prefix-refuses',True)
else: check('duplicate-prefix-refuses',False)
for value in ['/tmp/escape',str(R/'audit'/'..'/'..'/'escape')]:
 try: c.owned_path(value,'audit')
 except ValueError: check('owned-boundary-'+value,True)
 else: check('owned-boundary-'+value,False)
for value in [None,[],{},'']:
 try:c.parse_measurement(value)
 except (ValueError,TypeError):check('bad-schema-'+str(value),True)
 else:check('bad-schema-'+str(value),False)
s=c.parse_measurement({'argv':['/definitely-not-a-real-record-benchmark-command'],'cwd':str(P),'outputPrefix':str(P/'spawn-failure'),'timeoutSeconds':1,'domain':'audit','scenario':'spawn-failure','iteration':0,'mode':'collector-selfcheck'})
x=c.run_measurement(s)
check('spawn-failure-explicit-no-fake-cpu',x['outcome']=='spawn-error' and x['exitCode'] is None and all(x[k] is None for k in ['userSeconds','systemSeconds','cpuSeconds','maxRssKiB']) and x['spawnError']['errno']==2 and x['stdout']['bytes']==0 and x['stderr']['bytes']==0,x)
summary={'status' :'passed','collectorSha256':__import__('hashlib').sha256((R/'methods/collector.py').read_bytes()).hexdigest(),'checks':checks,'boundary':'microprobes only; normal fixture and workload counters not exercised; spawn failure exercised; wait4 exceptional-path cleanup inspected but not fault-injected'}
(P/'audit-results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'status':summary['status'],'checks':len(checks),'result':str(P/'audit-results.json')}))
