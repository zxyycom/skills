from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
C='261001-candidate-1';D='261001-candidate-2';A='261001-record-09001';B='261001-record-09002';Z='261001-record-10000';P='261001-record-08001'
rows=[]
def add(domain,key,args,setup='base',expected='selected changes only',exit=0,n=10000):
 rows.append(dict(domain=domain,id=key,argv=args,setup=setup,expected=expected,expectedExit=exit,formalCount=n,normalRepetitions=3,probeRepetitions=1))
drnew=['new','acceptance-new','--title','Acceptance new','--purpose','固定目的','--background','固定背景','--decision','固定决定','--tag','benchmark']
irnew=['new','acceptance-new','--formed-at','2026-10-24T00:00:00Z','--title','Acceptance new','--question','固定问题','--tag','benchmark']
add('decision','new',drnew,expected='date ID and full basename; index/formal/pending unchanged')
add('decision','publish-independent',['publish',C,'--alignment','unaligned'],expected='candidate becomes active with same ID;10001 formal;old formal unchanged')
add('decision','publish-predecessor',['publish',C,'--alignment','unaligned'],'candidate-predecessor','same ID;A archived;10001 formal;relation retained')
add('decision','discard-candidate',['discard',C,'--delete-recorded'],expected='C removed;index/formal unchanged')
add('decision','discard-formal',['discard',Z,'--delete-recorded'],expected='Z removed;9999 formal')
add('decision','rename-formal',['rename',P,'acceptance-renamed','--rename-recorded-decision'],expected='P identity/path and incoming A changed;unselected candidate deliberately unchanged')
add('decision','evolve-discard',['evolve','--successor','aligned='+B,'--relation','修订='+A,'--discard',Z,'--delete-recorded'],expected='A archived;B relation/alignment changed;Z deleted;9999 formal')
for s in ['all','domain','index']:
 add('decision','stage-'+s,['stage',A,'--scope',s],'stage','scope selected projection;full unselected pending mode/OID/deletion invariant;W invariant')
add('decision','bad-index',drnew,'bad-index','reject;W/P unchanged',1)
add('decision','bootstrap',['publish',C,'--alignment','unaligned'],'bootstrap','0→1 formal;valid initial index;candidate ID retained',n=0)
add('investigation','new',irnew,expected='full ID candidate directory+basename;formal/index/pending unchanged')
add('investigation','publish-independent',['publish',C],expected='same ID published;10001 formal;old formal unchanged')
add('investigation','publish-predecessor',['publish',C],'candidate-predecessor','same ID;index relation retained;10001 formal;predecessor current body unnecessary')
add('investigation','discard-candidate-owner',['discard',D,'--delete-recorded','--delete-owned-resources'],'candidate-owner','D and only its owner tree removed;index/formal and baseline owner unchanged')
add('investigation','discard-formal',['discard',Z,'--delete-recorded'],expected='Z removed;9999 formal')
add('investigation','rename-formal-owner',['rename','261001-record-00001','acceptance-renamed','--rename-recorded-report'],expected='ID/path and formal incoming reference changed;owner tree moved;unselected candidate unchanged')
for s in ['all','domain','index']:
 add('investigation','stage-'+s,['stage','261001-record-00001','--scope',s],'stage-owner','scope selected projection;owner complete tree only for domain/all;unselected pending mode/OID/deletion and W invariant')
add('investigation','missing-index',irnew,'missing-index','reject;W/P unchanged',1)
add('investigation','bootstrap',['publish',C],'bootstrap','0→1 formal;valid initial index;same ID',n=0)
assert len(rows)==23
(R/'preparation'/'matrix.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
print('Prepared',len(rows),'scenario specifications; no product CLI executed')
