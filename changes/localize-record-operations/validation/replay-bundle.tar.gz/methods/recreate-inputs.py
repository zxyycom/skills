"""Recreate exact 10k domain input bytes without retaining large indexes or original /tmp Git."""
from pathlib import Path
import json,sys
from oracle import projection,fingerprint,stable
T=Path(__file__).resolve().parent/'input-templates'
def generate(destination):
 assert not destination.exists(),'Refuse overwrite'
 for d,coll in [('decision','docs/decisions'),('investigation','docs/investigations')]:
  c=destination/d/coll;c.mkdir(parents=True)
  entries={};revisions={}
  for n in range(1,10001):
   i=f'261001-record-{n:05d}';base='261001-record-00001' if d=='decision' else '261001-record-00002'
   text=(T/(d+'-formal.md')).read_text().replace(base,i)
   if d=='decision':
    text=text.replace('status: "archived"','status: "active"' if n>9000 else 'status: "archived"')
    text=text.replace('alignment: "unaligned"','alignment: "aligned"' if n%2==0 else 'alignment: "unaligned"')
   if n>1000:
    kind='修订' if d=='decision' else '补充';pred=f'261001-record-{n-1000:05d}'
    text=text.replace('relations: []',f'relations:\n  - type: "{kind}"\n    target: "{pred}"')
   if d=='investigation' and n==1:text+='\n## 随附资源\n- [证据](./_resources/261001-record-00001/evidence.txt)\n'
   if n==10000:text+='needle-perf-unique\n\n'
   source=('archive/' if d=='decision' and n<=9000 else '')+i+'.md'
   p=c/source;p.parent.mkdir(exist_ok=True);p.write_text(text);p.chmod(0o644)
   _,entry,rev=projection(d,source,text.encode())
   if d=='decision':entry={k:entry[k] for k in ['name','sourcePath','title','status','alignment','createdAt','purpose','background','decision','tags','relations']}
   entries[i]=entry;revisions[i]=rev
  for n in [1,2]:
   i=f'261001-candidate-{n}';text=(T/(d+'-candidate.md')).read_text().replace('261001-candidate-1',i)
   (c/(i+'.md' if d=='decision' else '_candidate.'+i)).write_text(text)
  label='decision-index-metadata-v2' if d=='decision' else 'investigation-index-metadata-v4'
  index={'schemaVersion':4,'namespace':'decisions' if d=='decision' else 'investigations','definitionVersion':11,'metadata':{},'sourceRevision':{'entries':revisions,'metadata':fingerprint(label,'{}')},'entries':entries}
  (c/('decision-index.json' if d=='decision' else 'investigation-index.json')).write_text(json.dumps(index,ensure_ascii=False,indent=2,sort_keys=d=='investigation')+'\n')
  if d=='investigation':
   p=c/'_resources/261001-record-00001/evidence.txt';p.parent.mkdir(parents=True);p.write_bytes((T/'evidence.txt').read_bytes())
  for f in c.rglob('*'):
   if f.is_file():f.chmod(0o644)
if __name__=='__main__':generate(Path(sys.argv[1]))
