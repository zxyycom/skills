from pathlib import Path
import json,os,subprocess,hashlib
ROOT=Path(__file__).resolve().parents[1]; target=ROOT/'preparation'/'probe-selfcheck';target.mkdir()
collection=target/'records';collection.mkdir()
for p,data in [('formal.md','abc\n'),('index.json','{}'),('candidate.md','cand'),('_resources/r.txt','res')]:
 f=collection/p;f.parent.mkdir(exist_ok=True);f.write_text(data)
env=dict(os.environ,GIT_CONFIG_GLOBAL='/dev/null',GIT_CONFIG_NOSYSTEM='1')
def git(*args):return subprocess.check_output(['git','-C',str(target),*args],env=env).decode().strip()
git('init','-q');git('config','core.hooksPath','/dev/null')
oid=git('hash-object','-w','records/formal.md')
output=target/'output';output.mkdir()
config={'outputDir':str(output),'collectionRoot':str(collection),'indexFile':str(collection/'index.json'),'candidatePaths':[str(collection/'candidate.md')],'resourceRoots':[str(collection/'_resources')],'gitObjectRoles':{'head':[oid],'pending':[oid]}}
cfg=target/'config.json';cfg.write_text(json.dumps(config))
env.update(RECORD_BENCH_PROBE_CONFIG=str(cfg),RECORD_BENCH_SELFCHECK_ROOT=str(target),RECORD_BENCH_SELFCHECK_OID=oid)
run=subprocess.run(['node','--import',str(ROOT/'methods'/'preload.mjs'),str(ROOT/'methods'/'probe-selfcheck.mjs')],env=env,capture_output=True)
(target/'stdout').write_bytes(run.stdout);(target/'stderr').write_bytes(run.stderr)
assert run.returncode==0,run.stderr
events=[json.loads(line) for p in output.glob('*.events.jsonl') for line in p.read_text().splitlines()]
io=[e['value'] for e in events if e['type']=='io']
formal=[e for e in io if e['category']=='formal' and e['direction']=='read']
assert sum(e['calls'] for e in formal)==6,formal
assert sum(e['bytes'] for e in formal)==22,formal
for cat,n in [('index',2),('candidate',4),('resource',3)]:
 rows=[e for e in io if e['category']==cat and e['direction']=='read'];assert sum(e['bytes'] for e in rows)==n,rows
batches=[e['value'] for e in events if e['type']=='git' and e['value']['batch']]
assert len(batches)==1 and batches[0]['batch']['payloadBytes']==8,batches
assert len(batches[0]['batch']['blobs'])==2
assert all(b['roles']==['head','pending'] for b in batches[0]['batch']['blobs'])
assert batches[0]['stdoutBytes']==sum(batches[0]['batch'][k] for k in ['payloadBytes','headerBytes','trailerBytes'])
assert len([e for e in events if e['type']=='start'])==2
assert len([e for e in events if e['type']=='end'])==2
assert not [u for e in events if e['type']=='end' for u in e['value']['unknown']]
summary={'status':'passed','formalCalls':6,'formalBytes':22,'threads':2,'gitPayloadBytes':8,'duplicateOidCount':2,'gitDualRolesPreserved':True,'observerSha256':hashlib.sha256((ROOT/'methods'/'preload.mjs').read_bytes()).hexdigest(),'boundary':'Synthetic APIs and worker only; production API closure must be checked at freeze.'}
(target/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary))
