"""Prepare immutable scenario initial states with direct independent fixture edits."""
from pathlib import Path
import copy,json,os,shutil,subprocess,sys
from oracle import capture,verify_index,git,collection,index_name,projection,summary,sha
ROOT=Path(__file__).resolve().parents[1];MATRIX=json.loads((ROOT/'preparation/matrix.json').read_text())
ENV={k:v for k,v in os.environ.items() if not k.startswith('GIT_')}
ENV.update(GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_AUTHOR_DATE='2026-10-01T00:00:00Z',GIT_COMMITTER_DATE='2026-10-01T00:00:00Z',PATH='/home/dev/.local/share/mise/installs/bun/1.4.2/bin:'+os.environ['PATH'])
os.environ.update(ENV)
def command(root,args,label):
 p=subprocess.run(args,cwd=root,env=ENV,capture_output=True);out=ROOT/'preparation'/'cli';out.mkdir(exist_ok=True)
 (out/(label+'.stdout')).write_bytes(p.stdout);(out/(label+'.stderr')).write_bytes(p.stderr)
 (out/(label+'.json')).write_text(json.dumps({'argv':args,'exitCode':p.returncode})+'\n')
 assert p.returncode==0,(label,p.stderr.decode())
def cli(domain):return ROOT/'snapshot/skills'/('decision-records/scripts/decision-records.ts' if domain=='decision' else 'investigation-report/scripts/check-investigations.ts')
def write_index(path,idx):path.write_text(json.dumps(idx,ensure_ascii=False,indent=2)+'\n')
def update(idx,d,c,file):
 identity,entry,rev=projection(d,file.relative_to(c).as_posix(),file.read_bytes());idx['entries'][identity]=entry;idx['sourceRevision']['entries'][identity]=rev
proofs=[]
for domain in ['decision','investigation']:
 base=ROOT/'templates'/domain
 s=capture(base,domain);p=verify_index(base,domain,s)
 if '--skip-product-check' not in sys.argv:command(base,['node',str(cli(domain)),'--root',str(base),'check'],domain+'-initial-check')
 proofs.append({'domain':domain,'kind':'template','state':summary(s),'oracle':p})
for row in MATRIX:
 d=row['domain'];key=row['id'];target=ROOT/'fixtures'/(d+'-'+key)
 target.parent.mkdir(exist_ok=True);shutil.copytree(ROOT/'templates'/d,target)
 c=target/collection(d);idxfile=c/index_name(d);idx=json.loads(idxfile.read_text())
 C='261001-candidate-1';D='261001-candidate-2'
 candidate=lambda i:c/(i+'.md' if d=='decision' else '_candidate.'+i)
 if row['setup']=='candidate-predecessor':
  p=candidate(C);text=p.read_text()
  pred='261001-record-09001' if d=='decision' else '261001-record-09999';kind='修订' if d=='decision' else '补充'
  p.write_text(text.replace('relations: []',f'relations:\n  - type: "{kind}"\n    target: "{pred}"\n    summary: "acceptance predecessor"'))
 elif row['setup']=='candidate-owner':
  resource=c/'_resources'/D/'evidence.txt';resource.parent.mkdir();resource.write_text('candidate owner evidence\n')
  p=candidate(D);p.write_text(p.read_text()+f'\n## 随附资源\n- [evidence](./_resources/{D}/evidence.txt)\n')
 elif key.startswith('rename-'):
  old='261001-record-08001' if d=='decision' else '261001-record-00001'
  p=candidate(C);kind='修订' if d=='decision' else '补充'
  p.write_text(p.read_text().replace('relations: []',f'relations:\n  - type: "{kind}"\n    target: "{old}"\n    summary: "deliberately unselected candidate"'))
  if d=='investigation':p.write_text(p.read_text()+f'\n- [old owner reference](./_resources/{old}/evidence.txt)\n')
 elif row['setup']=='bootstrap':
  for p in list(c.rglob('*')):
   if p.is_file() and p not in [candidate(C),candidate(D)]:p.unlink()
  for p in sorted(c.rglob('*'),reverse=True):
   if p.is_dir() and not list(p.iterdir()):p.rmdir()
 elif row['setup']=='bad-index':idxfile.write_text('{bad index\n')
 elif row['setup']=='missing-index':idxfile.unlink()
 if row['setup'] not in ['stage','stage-owner']:
  git(target,'add','-A')
  # all scenarios receive a stable, independent initial HEAD; no hooks/remotes.
  git(target,'-c','user.name=Acceptance Fixture','-c','user.email=fixture@example.invalid','commit','--allow-empty','-qm','Freeze scenario '+key)
 else:
  A='261001-record-09001' if d=='decision' else '261001-record-00001'
  B='261001-record-09002' if d=='decision' else '261001-record-09998'
  Y='261001-record-09003' if d=='decision' else '261001-record-09997'
  # Add selected owner stale member to HEAD, so domain/all must remove it.
  if d=='investigation':
   stale=c/'_resources'/A/'stale.txt';stale.write_text('HEAD-only owner stale\n')
   git(target,'add','-A');git(target,'commit','-qm','Baseline complete owner tree')
  original_b=(c/idx['entries'][B]['sourcePath']).read_bytes();original_y=(c/idx['entries'][Y]['sourcePath']).read_bytes()
  b=c/idx['entries'][B]['sourcePath'];ypath=c/idx['entries'][Y]['sourcePath']
  b.write_bytes(original_b+b'\nUNSELECTED_PENDING_B\n');b.chmod(0o755)
  yp=str(ypath.relative_to(target));ypath.unlink()
  pending_idx=copy.deepcopy(idx);update(pending_idx,d,c,b)
  del pending_idx['entries'][Y];del pending_idx['sourceRevision']['entries'][Y]
  write_index(idxfile,pending_idx);git(target,'add','-A')
  # Worktree intentionally differs from unselected P; only selected A is refreshed.
  b.write_bytes(original_b);b.chmod(0o644);ypath.write_bytes(original_y);ypath.chmod(0o644)
  a=c/idx['entries'][A]['sourcePath']
  if d=='investigation':a.write_text(a.read_text().replace('## 随附资源','SELECTED_CURRENT_A\n\n## 随附资源'))
  else:a.write_bytes(a.read_bytes()+b'\nSELECTED_CURRENT_A\n')
  update(idx,d,c,a);write_index(idxfile,idx)
  if d=='investigation':
   owner=c/'_resources'/A
   (owner/'evidence.txt').write_text('selected owner current evidence\n')
   (owner/'stale.txt').unlink();(owner/'extra.txt').write_text('selected unreferenced owner member\n')
 s=capture(target,d)
 if row['expectedExit']==0:
  check=verify_index(target,d,s) if row['setup']!='bootstrap' else {'formal':0,'index':'absent'}
 else:check={'formal':10000,'index':row['setup']}
 assert len([v for v in s['docs'].values() if (v['metadata'].get('status')!='candidate' if d=='decision' else not v['path'].startswith('_candidate.'))])==row['formalCount']
 proofs.append({'domain':d,'scenario':key,'state':summary(s),'oracle':check})
 # Preserve initial pending index for exact sample restoration, outside the fixture W.
 (target.parent/(target.name+'.git-index')).write_bytes((target/'.git/index').read_bytes())
 print(d,key,'prepared',flush=True)
(ROOT/'preparation/final-fixtures.json').write_text(json.dumps(proofs,ensure_ascii=False,indent=2)+'\n')
