import fs from 'node:fs';
import fsp from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {Worker,isMainThread,workerData} from 'node:worker_threads';
const root=process.env.RECORD_BENCH_SELFCHECK_ROOT;
const body=root+'/records/formal.md';
if (!isMainThread) {
 if ((await fsp.readFile(body)).length!==4) throw new Error('worker result');
} else {
 if(fs.readFileSync(body).length!==4)throw new Error('sync');
 if((await fsp.readFile(body)).length!==4)throw new Error('promise');
 const fh=await fsp.open(body,'r');
 if((await fh.readFile()).length!==4)throw new Error('handle');
 await fh.close();
 const partial=await fsp.open(body,'r');
 if((await partial.read(Buffer.alloc(2),0,2,0)).bytesRead!==2)throw new Error('partial');
 await partial.close();
 await new Promise((resolve,reject)=>fs.readFile(body,(e,b)=>e?reject(e):b.length===4?resolve():reject(new Error('callback'))));
 await fsp.readFile(root+'/records/index.json');
 await fsp.readFile(root+'/records/candidate.md');
 await fsp.readFile(root+'/records/_resources/r.txt');
 const worker=new Worker(new URL(import.meta.url));
 await new Promise((resolve,reject)=>{worker.on('error',reject);worker.on('exit',c=>c?reject(new Error('worker exit')):resolve());});
 const oid=process.env.RECORD_BENCH_SELFCHECK_OID;
 const child=spawn('git',['-C',root,'cat-file','--batch']);
 let out=Buffer.alloc(0);child.stdout.on('data',b=>{out=Buffer.concat([out,b]);});
 child.stdin.end(oid+'\n'+oid+'\n');
 await new Promise((resolve,reject)=>{child.on('error',reject);child.on('close',c=>c?reject(new Error('git exit')):resolve());});
 if(!out.toString().includes('blob 4\nabc\n\n'))throw new Error('git protocol');
 console.log('probe selfcheck success');
}
