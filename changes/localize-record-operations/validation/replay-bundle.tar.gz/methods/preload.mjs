/**
 * One-run workload observer. Only probe invocations import this module.
 * @typedef {{file:string,sha256:string,needle:string,insert:string}} SourceHook
 * @typedef {{outputDir:string,collectionRoot:string,indexFile:string,candidatePaths?:string[],resourceRoots?:string[],gitObjectRoles?:Record<string,string[]>,hooks?:SourceHook[]}} ProbeConfig
 * @typedef {{path:string,category:string,direction:'read'|'write',method:string,calls:number,bytes:number}} IoObservation
 * Config is a JSON boundary validated below. Operation state belongs to this thread;
 * JSONL append is the authoritative cross-thread handoff, not a shared mutable map.
 */
import fs from 'node:fs';
import fsp from 'node:fs/promises';
import cp from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createHash } from 'node:crypto';
import { registerHooks, syncBuiltinESMExports } from 'node:module';
import { threadId, isMainThread } from 'node:worker_threads';
import { AsyncLocalStorage } from 'node:async_hooks';

const rawRead = fs.readFileSync.bind(fs);
const rawWrite = fs.writeFileSync.bind(fs);
const rawAppend = fs.appendFileSync.bind(fs);
const configPath = process.env.RECORD_BENCH_PROBE_CONFIG;
if (!configPath) throw new Error('RECORD_BENCH_PROBE_CONFIG is required for probe');
const config = JSON.parse(rawRead(configPath, 'utf8'));
if (!config || typeof config !== 'object' || typeof config.outputDir !== 'string' || typeof config.collectionRoot !== 'string' || typeof config.indexFile !== 'string') {
  throw new Error('Invalid probe config: outputDir/collectionRoot/indexFile required');
}
for (const key of ['candidatePaths', 'resourceRoots', 'hooks']) {
  if (config[key] !== undefined && !Array.isArray(config[key])) throw new Error('Invalid array '+key);
}
for(const key of ['candidatePaths','resourceRoots']) {
  if((config[key]??[]).some(p=>typeof p!=='string'||!path.isAbsolute(p)))throw new Error('Invalid absolute paths '+key);
}
if(config.gitObjectRoles!==undefined && (!config.gitObjectRoles||typeof config.gitObjectRoles!=='object'||Object.values(config.gitObjectRoles).some(oids=>!Array.isArray(oids)||oids.some(oid=>typeof oid!=='string'||!/^[0-9a-f]{40,64}$/u.test(oid)))))throw new Error('Invalid Git object role map');
const collectionRoot = path.resolve(config.collectionRoot);
const indexFile = path.resolve(config.indexFile);
const observedRoles = new Map();
const candidates = new Set((config.candidatePaths ?? []).map(p => path.resolve(p)));
const resources = (config.resourceRoots ?? []).map(p => path.resolve(p));
const state = {schemaVersion:1, pid:process.pid,threadId,isMainThread,io:[],git:[],counts:{},transforms:[],unknown:[],boundaries:[
  'Logical Node FS API completed bytes; nested readFile/read and writeFile/write deduplicated.',
  'Successful readFile string byte length uses returned text encoding; all benchmark source reads use Buffer or UTF-8.',
  'Failed high-level IO can transfer partial bytes without reporting them; marked unknown.',
  'Git subprocess internal filesystem IO is not observed. Git stdout protocol bytes are observed.',
  'Kernel cache/storage physical reads, mmap, native-addon direct IO, and Node module-loader internals are outside this observer.'
]};
const eventPath=path.join(config.outputDir,`probe-${process.pid}-${threadId}.events.jsonl`);
let observerIO=false;
function event(type,value) { observerIO=true; try { rawAppend(eventPath,JSON.stringify({type,value})+'\n'); } finally { observerIO=false; } }
event('start',{schemaVersion:1,pid:process.pid,threadId,isMainThread});
const fds = new Map();
const io = new Map();
let syncDepth = 0;
let gitSequence = 0;
function textPath(value) {
  if (typeof value === 'number') return fds.get(value) ?? `unknown-fd:${value}`;
  if (value instanceof URL) return fileURLToPath(value);
  if (typeof value === 'string' || Buffer.isBuffer(value)) return path.resolve(String(value));
  return 'unknown-path';
}
function category(p) {
  if (p === indexFile) return 'index';
  if (observedRoles.has(p)) return observedRoles.get(p);
  if (candidates.has(p)) return 'candidate';
  if (resources.some(r => p === r || p.startsWith(r+path.sep))) return 'resource';
  if (p.startsWith(collectionRoot+path.sep) && p.endsWith('.md')) return 'formal';
  if (p === collectionRoot || p.startsWith(collectionRoot+path.sep)) return 'collection-other';
  if (p.startsWith('unknown-')) return 'unknown';
  return 'other';
}
function length(data, encoding='utf8') {
  if (typeof data === 'string') return Buffer.byteLength(data, typeof encoding === 'string' ? encoding : 'utf8');
  if (ArrayBuffer.isView(data)) return data.byteLength;
  return null;
}
function record(p, direction, method, bytes, content) {
  if(observerIO)return;
  if(p.startsWith(collectionRoot+path.sep) && p.endsWith('.md') && (typeof content==='string'||Buffer.isBuffer(content))) {
    const header=(typeof content==='string'?content:content.toString('utf8',0,Math.min(content.length,4096)));
    if(/^\ufeff?---\r?\n/u.test(header)) {
      const status=/^status:\s*["']?(candidate|active|archived)["']?\s*$/mu.exec(header);
      if(status)observedRoles.set(p,status[1]==='candidate'?'candidate':'formal');
    }
  }
  if (!Number.isSafeInteger(bytes) || bytes < 0) { state.unknown.push({p,direction,method,reason:'unreported-byte-count'}); return; }
  const key=JSON.stringify([p,direction,method]);
  const prior=io.get(key) ?? {path:p,category:category(p),direction,method,calls:0,bytes:0};
  prior.calls++; prior.bytes+=bytes; io.set(key,prior); event('io',{path:p,category:category(p),direction,method,calls:1,bytes});
}
function failed(p,direction,method,error) {
  if(observerIO)return;
  state.unknown.push({path:p,direction,method,reason:'failed-operation-partial-bytes-unknown',error:error instanceof Error ? error.message : String(error)});
}
globalThis.__recordProbeCount = (name,amount=1) => {
  if (typeof name !== 'string' || !Number.isFinite(amount)) throw new Error('Invalid probe count');
  state.counts[name] = (state.counts[name] ?? 0)+amount; event('count',{name,amount});
};

// Synchronous APIs: depth suppression prevents readFileSync(fd)->readSync double count.
const rawOpenSync=fs.openSync; const rawCloseSync=fs.closeSync;
fs.openSync=function(...args) { const fd=Reflect.apply(rawOpenSync,this,args); fds.set(fd,textPath(args[0])); return fd; };
fs.closeSync=function(fd) { try { return rawCloseSync(fd); } finally { fds.delete(fd); } };
for (const [name,direction] of [['readFileSync','read'],['writeFileSync','write'],['appendFileSync','write'],['readSync','read'],['writeSync','write']]) {
  const original=fs[name];
  fs[name]=function(...args) {
    const nested=syncDepth>0; const p=textPath(args[0]); syncDepth++;
    try {
      const result=Reflect.apply(original,this,args);
      if (!nested) {
        const bytes=name==='readFileSync' ? length(result,args[1]?.encoding ?? args[1]) : name==='readSync'||name==='writeSync' ? result : length(args[1],args[2]?.encoding ?? args[2]);
        record(p,direction,name,bytes,name==='readFileSync'?result:direction==='write'?args[1]:undefined);
      }
      return result;
    } catch(error) { if (!nested) failed(p,direction,name,error); throw error; }
    finally { syncDepth--; }
  };
}

// Promise path APIs are high-level boundaries and do not call the exported open wrapper.
for (const [name,direction] of [['readFile','read'],['writeFile','write'],['appendFile','write']]) {
  const original=fsp[name];
  fsp[name]=async function(...args) {
    const p=textPath(args[0]);
    try { const result=await Reflect.apply(original,this,args); record(p,direction,name,name==='readFile'?length(result,args[1]?.encoding ?? args[1]):length(args[1],args[2]?.encoding ?? args[2]),name==='readFile'?result:args[1]); return result; }
    catch(error) { failed(p,direction,name,error); throw error; }
  };
}
const handleContext=new AsyncLocalStorage();
const rawOpen=fsp.open;
fsp.open=async function(...args) {
  const p=textPath(args[0]); const handle=await Reflect.apply(rawOpen,this,args); fds.set(handle.fd,p);
  for (const [name,direction] of [['readFile','read'],['writeFile','write'],['appendFile','write'],['read','read'],['write','write'],['readv','read'],['writev','write']]) {
    const original=handle[name];
    handle[name]=async function(...values) {
      const ancestors=handleContext.getStore() ?? new Set();
      const nested=ancestors.has(handle);
      const context=new Set([...ancestors,handle]);
      try {
        const result=await handleContext.run(context,()=>Reflect.apply(original,this,values));
        if (!nested) {
          const bytes=['read','readv'].includes(name)?result.bytesRead:['write','writev'].includes(name)?result.bytesWritten:name==='readFile'?length(result,values[0]?.encoding ?? values[0]):length(values[0],values[1]?.encoding ?? values[1]);
          record(p,direction,'FileHandle.'+name,bytes,name==='readFile'?result:name==='read'?result.buffer:direction==='write'?values[0]:undefined);
        }
        return result;
      } catch(error) { if (!nested) failed(p,direction,'FileHandle.'+name,error); throw error; }
    };
  }
  const close=handle.close.bind(handle); const fd=handle.fd;
  handle.close=async function() { try { return await close(); } finally { fds.delete(fd); } };
  return handle;
};

// Per-call async context suppresses internal callback write/read without suppressing concurrent calls.
const callbackContext=new AsyncLocalStorage();
// Callback APIs used by consumers are observed without replacing their callback semantics.
const rawOpenCallback=fs.open;
fs.open=function(...args) {
  const callback=args.at(-1); const p=textPath(args[0]);
  if (typeof callback!=='function') return Reflect.apply(rawOpenCallback,this,args);
  args[args.length-1]=function(error,fd) { if (!error) fds.set(fd,p); return callback(error,fd); };
  return Reflect.apply(rawOpenCallback,this,args);
};
for (const [name,direction] of [['readFile','read'],['writeFile','write'],['appendFile','write'],['read','read'],['write','write']]) {
  const original=fs[name];
  fs[name]=function(...args) {
    const callback=args.at(-1); const p=textPath(args[0]);
    if (typeof callback!=='function' || callbackContext.getStore()===true) return Reflect.apply(original,this,args);
    args[args.length-1]=function(error,result,...rest) {
      if (error) failed(p,direction,name,error);
      else record(p,direction,name,name==='readFile'?length(result,args[1]?.encoding ?? args[1]):name==='read'||name==='write'?result:length(args[1],args[2]?.encoding ?? args[2]),name==='readFile'?result:direction==='write'?args[1]:undefined);
      return callbackContext.run(false,()=>callback(error,result,...rest));
    };
    return callbackContext.run(true,()=>Reflect.apply(original,this,args));
  };
}

function parseBatch(buffer) {
  const blobs=[]; let offset=0; let headerBytes=0; let payloadBytes=0;
  while(offset<buffer.length) {
    const end=buffer.indexOf(10,offset); if(end<0) throw new Error('truncated batch header');
    const header=buffer.subarray(offset,end).toString('ascii'); const match=/^([0-9a-f]+) blob (\d+)$/.exec(header);
    if(!match) throw new Error('unexpected batch header: '+header);
    const size=Number(match[2]); headerBytes+=end+1-offset; offset=end+1;
    if(!Number.isSafeInteger(size)||offset+size>=buffer.length||buffer[offset+size]!==10) throw new Error('truncated batch payload');
    const memberships=Object.entries(config.gitObjectRoles ?? {}).filter(([,oids])=>oids.includes(match[1])).map(([role])=>role);
    blobs.push({oid:match[1],bytes:size,roles:memberships.length?memberships:['unknown']}); payloadBytes+=size; offset+=size+1;
  }
  return {blobs,headerBytes,payloadBytes,trailerBytes:blobs.length};
}
function observeChild(child,command,args) {
  if (path.basename(String(command))!=='git') return child;
  const entry={sequence:gitSequence++,command:String(command),argv:args,stdoutBytes:0,stderrBytes:0,requests:[],batch:null,exitCode:null};
  state.git.push(entry); const stdout=[];
  if(child.stdout) child.stdout.on('data',chunk => { const data=Buffer.isBuffer(chunk)?chunk:Buffer.from(chunk); entry.stdoutBytes+=data.length; if(args.includes('cat-file')&&args.includes('--batch')) stdout.push(data); });
  if(child.stderr) child.stderr.on('data',chunk => {entry.stderrBytes+=Buffer.byteLength(chunk);});
  if(child.stdin) {
    const write=child.stdin.write.bind(child.stdin); const end=child.stdin.end.bind(child.stdin); let input='';
    child.stdin.write=function(...values) { if(typeof values[0]==='string'||Buffer.isBuffer(values[0])) input+=String(values[0]); return Reflect.apply(write,this,values); };
    child.stdin.end=function(...values) { if(typeof values[0]==='string'||Buffer.isBuffer(values[0])) input+=String(values[0]); entry.requests=input.split('\n').filter(Boolean); return Reflect.apply(end,this,values); };
  }
  child.once('close',code => { entry.exitCode=code; if(stdout.length) { try {entry.batch=parseBatch(Buffer.concat(stdout));} catch(error) {entry.batch={error:String(error),payloadBytes:null};state.unknown.push({reason:'git-batch-frame-failure',sequence:entry.sequence});} } event('git',entry); });
  return child;
}
for (const name of ['spawn','execFile']) {
  const original=cp[name];
  cp[name]=function(...args) { return observeChild(Reflect.apply(original,this,args),args[0],Array.isArray(args[1])?args[1]:[]); };
}
// Mutation of built-ins must precede loading production ESM named imports, also in workers.
syncBuiltinESMExports();

const specs=config.hooks ?? [];
for (const spec of specs) {
  if(!spec||typeof spec.file!=='string'||typeof spec.sha256!=='string'||typeof spec.needle!=='string'||typeof spec.insert!=='string') throw new Error('Invalid source hook spec');
}
if(specs.length) registerHooks({load(url,context,nextLoad) {
  const result=nextLoad(url,context); const file=url.startsWith('file:')?fileURLToPath(url):null;
  const matches=specs.filter(spec=>path.resolve(spec.file)===file);
  if(!matches.length) return result;
  let source=typeof result.source==='string'?result.source:Buffer.from(result.source).toString('utf8');
  const originalSha=createHash('sha256').update(source).digest('hex');
  for(const spec of matches) {
    if(spec.sha256!==originalSha) throw new Error('Probe source fingerprint mismatch: '+file);
    if(source.split(spec.needle).length!==2) throw new Error('Probe hook needle not unique: '+file);
    source=source.replace(spec.needle,spec.needle+spec.insert);
    state.transforms.push({file,originalSha,needle:spec.needle,insert:spec.insert});
  }
  state.transforms.push({file,transformedSha:createHash('sha256').update(source).digest('hex')});
  return {...result,source};
}});

process.on('exit',()=> {
  state.io=[...io.values()];
  event('end',{unknown:state.unknown,boundaries:state.boundaries,transforms:state.transforms});
  observerIO=true;
  rawWrite(path.join(config.outputDir,`probe-${process.pid}-${threadId}.json`),JSON.stringify(state,null,2)+'\n');
});
