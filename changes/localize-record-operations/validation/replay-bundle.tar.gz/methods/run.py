"""Run preserved observations serially; any product failure stops the acceptance batch."""
from pathlib import Path
from datetime import datetime,timezone
import importlib.util,json,os,re,shutil,sys,traceback
from oracle import capture,collection,index_name,summary,verify_effect,stable,sha,git
from workload import configuration,summarize
from collector import parse_measurement,run_measurement
ROOT=Path(__file__).resolve().parents[1]
os.environ['PATH']='/home/dev/.local/share/mise/installs/bun/1.4.2/bin:'+os.environ['PATH']
os.environ['GIT_CONFIG_GLOBAL']='/dev/null';os.environ['GIT_CONFIG_NOSYSTEM']='1'
MATRIX=json.loads((ROOT/'preparation/matrix.json').read_text())
def cli(d):return ROOT/'snapshot/skills'/('decision-records/scripts/decision-records.ts' if d=='decision' else 'investigation-report/scripts/check-investigations.ts')
def normalized(row,before,after):
 files=dict(after['files']);notes=[]
 if row['domain']=='decision' and row['id'] in ['publish-independent','publish-predecessor','bootstrap']:
  C='261001-candidate-1';doc=after['docs'][C];timestamp=doc['metadata']['createdAt']
  assert isinstance(timestamp,str) and timestamp
  source=collection('decision')+'/'+doc['path'];index=collection('decision')+'/'+index_name('decision')
  raw=after['raws'][source];assert raw.count(timestamp.encode())==1
  data=raw.replace(timestamp.encode(),b'<createdAt>')
  files[source]=dict(files[source],sha256=sha(data),bytes=len(data))
  revision=after['index']['sourceRevision']['entries'][C]
  raw=after['raws'][index];assert raw.count(timestamp.encode())==1 and raw.count(revision.encode())==1
  data=raw.replace(timestamp.encode(),b'<createdAt>').replace(revision.encode(),b'<revision-for-createdAt>')
  files[index]=dict(files[index],sha256=sha(data),bytes=len(data))
  notes=[{'id':C,'createdAt':timestamp,'sourceRevision':revision,'scope':'exactly promoted C createdAt and corresponding source fingerprint; no other replacement'}]
 return {'worktreeSha256':stable(files),'pendingSha256':stable(after['pending']),'head':after['head']},notes
def append(path,value):
 with path.open('a') as f:f.write(json.dumps(value,ensure_ascii=False)+'\n')
def execute(row,iteration,mode):
 name=row['domain']+'-'+row['id'];fixture=ROOT/'fixtures'/name;root=ROOT/'working'/name
 if root.exists():shutil.rmtree(root)
 root.parent.mkdir(exist_ok=True);shutil.copytree(fixture,root)
 before=capture(root,row['domain']);out=ROOT/'runs'/name/(str(iteration)+'-'+mode)
 if out.exists():
  attempt=1
  while (ROOT/'runs'/name/(str(iteration)+'-'+mode+'.repair'+str(attempt))).exists():attempt+=1
  out=ROOT/'runs'/name/(str(iteration)+'-'+mode+'.repair'+str(attempt))
 out.mkdir(parents=True)
 (out/'before-manifest.json').write_text(json.dumps({'files':before['files'],'pending':before['pending']},sort_keys=True)+'\n')
 argv=['node'];environment={}
 if mode=='instrumented':
  probe=out/'probe';probe.mkdir();cfg=configuration(row,root,before,probe);cfgpath=out/'probe-config.json';cfgpath.write_text(json.dumps(cfg)+'\n')
  argv+=['--import',str(ROOT/'methods/preload.mjs')];environment['RECORD_BENCH_PROBE_CONFIG']=str(cfgpath)
 argv+=[str(cli(row['domain'])),'--root',str(root),*row['argv']]
 specification={'argv':argv,'cwd':str(root),'outputPrefix':str(out/'process'),'timeoutSeconds':600,'domain':row['domain'],'scenario':row['id'],'iteration':iteration,'mode':mode,'environment':environment}
 (out/'specification.json').write_text(json.dumps(specification,ensure_ascii=False,indent=2)+'\n')
 metrics=run_measurement(parse_measurement(specification))
 after=capture(root,row['domain'])
 (out/'after-manifest.json').write_text(json.dumps({'files':after['files'],'pending':after['pending']},sort_keys=True)+'\n')
 result={'domain':row['domain'],'scenario':row['id'],'iteration':iteration,'mode':mode,'metrics':metrics,'before':summary(before),'after':summary(after),'status':'unverified','rawDirectory':str(out)}
 try:
  assert metrics['exitCode']==row['expectedExit'] and not metrics['timedOut'],('exit',metrics['exitCode'],row['expectedExit'],(out/'process.stderr').read_text())
  result['effect']=verify_effect(row,root,before,after)
  result['normalizedState'],result['normalization']=normalized(row,before,after)
  output_key=(metrics['stdout']['sha256'],metrics['stderr']['sha256'])
  result['outputEqualityKey']=output_key
  baseline=BASELINES.get(name)
  if baseline:
   assert result['before']==baseline['before'],'initial state differs'
   assert result['normalizedState']==baseline['normalizedState'],'normal/probe final state mismatch'
   assert output_key==tuple(baseline['outputEqualityKey']),'normal/probe complete output mismatch'
  else:BASELINES[name]=result
  if mode=='instrumented':
   result['workload']=summarize(row,root,before,after,out/'probe')
   assert result['workload']['boundary']['status']=='passed',result['workload']['boundary']
   # Failed high-level IO has unknown partial-byte count; preserve it, never claim zero.
   assert result['workload']['threads']==result['workload']['threadsEnded'],'probe missing thread completion'
  result['status']='passed'
 except Exception as error:
  result['status']='failed';result['error']=str(error);result['traceback']=traceback.format_exc()
 append(ROOT/'observations.jsonl',result)
 print(json.dumps({'domain':row['domain'],'scenario':row['id'],'iteration':iteration,'mode':mode,'status':result['status'],'wall':metrics['wallSeconds'],'cpu':metrics['cpuSeconds'],'rssKiB':metrics['maxRssKiB'],'error':result.get('error')},ensure_ascii=False),flush=True)
 if result['status']!='passed':raise RuntimeError('Acceptance stopped; failed observation retained at '+str(out))
 return result
BASELINES={}
if __name__=='__main__':
 completed=set()
 if '--resume' in sys.argv:
  prior=[json.loads(line) for line in (ROOT/'observations.jsonl').read_text().splitlines()]
  amendments=[json.loads(line)['correctedObservation'] for line in (ROOT/'adjudications.jsonl').read_text().splitlines()] if (ROOT/'adjudications.jsonl').exists() else []
  def key(x):return (x['domain'],x.get('scenario',x.get('id')),x['iteration'],x['mode'])
  amended={key(x):x for x in amendments}
  invalid={json.loads(line)['originalObservationSha256'] for line in (ROOT/'invalidations.jsonl').read_text().splitlines()} if (ROOT/'invalidations.jsonl').exists() else set()
  for original in prior:
   if sha(json.dumps(original,ensure_ascii=False).encode()) in invalid:continue
   result=amended.get(key(original),original)
   assert result['status']=='passed','Unresolved prior failure cannot be skipped'
   completed.add(key(result));BASELINES.setdefault(result['domain']+'-'+result['scenario'],result)
 else:assert not (ROOT/'observations.jsonl').exists(),'Do not overwrite prior samples; explicit --resume required'
 for iteration,rows in [(1,MATRIX),(2,list(reversed(MATRIX))),(3,MATRIX)]:
  for row in rows:
   if (row['domain'],row['id'],iteration,'normal') not in completed:execute(row,iteration,'normal')
 for row in MATRIX:
  if (row['domain'],row['id'],4,'instrumented') not in completed:execute(row,4,'instrumented')
 print('All 92 scheduled observations completed',flush=True)
